<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["INITIAL_USERS",50],["USER_A",51],["User",45],["expect",44]]],["Function","xf",[["expectUser",61],["expectUserToFollow",107],["expectUsersToContain",76],["expectUsersToNotContain",93]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">//</span>
<a class="l" name="2" href="#2">2</a><span class="c">// User model tests. These are basically CRUD tests, ordered to let us test</span>
<a class="l" name="3" href="#3">3</a><span class="c">// all cases, plus listing all users and <a href="/source/s?path=following/">following</a>/<a href="/source/s?path=following/unfollowing">unfollowing</a> between users.</span>
<a class="l" name="4" href="#4">4</a><span class="c">//</span>
<a class="l" name="5" href="#5">5</a><span class="c">// It's worth noting that there may already be users in the database, so these</span>
<a class="l" name="6" href="#6">6</a><span class="c">// tests must not assume the initial state is empty.</span>
<a class="l" name="7" href="#7">7</a><span class="c">//</span>
<a class="l" name="8" href="#8">8</a><span class="c">// High-level test plan:</span>
<a class="l" name="9" href="#9">9</a><span class="c">//</span>
<a class="hl" name="10" href="#10">10</a><span class="c">// - List initial users.</span>
<a class="l" name="11" href="#11">11</a><span class="c">// - Create a user A.</span>
<a class="l" name="12" href="#12">12</a><span class="c">// - Fetch user A. Should be the same.</span>
<a class="l" name="13" href="#13">13</a><span class="c">// - List users again; should be initial list plus user A.</span>
<a class="l" name="14" href="#14">14</a><span class="c">// - Update user A, e.g. its name.</span>
<a class="l" name="15" href="#15">15</a><span class="c">// - Fetch user A again. It should be updated.</span>
<a class="l" name="16" href="#16">16</a><span class="c">// - Delete user A.</span>
<a class="l" name="17" href="#17">17</a><span class="c">// - Try to fetch user A again; should fail.</span>
<a class="l" name="18" href="#18">18</a><span class="c">// - List users again; should be back to initial list.</span>
<a class="l" name="19" href="#19">19</a><span class="c">//</span>
<a class="hl" name="20" href="#20">20</a><span class="c">// - Create two users in parallel, B and C.</span>
<a class="l" name="21" href="#21">21</a><span class="c">// - Fetch both user's "following and others"; both should show no following.</span>
<a class="l" name="22" href="#22">22</a><span class="c">// - Have user B follow user C.</span>
<a class="l" name="23" href="#23">23</a><span class="c">// - Have user B follow user C again; should be idempotent.</span>
<a class="l" name="24" href="#24">24</a><span class="c">// - Fetch user B's "following and others"; should show following user C.</span>
<a class="l" name="25" href="#25">25</a><span class="c">// - Fetch user C's "following and others"; should show not following user B.</span>
<a class="l" name="26" href="#26">26</a><span class="c">// - Have user B unfollow user C.</span>
<a class="l" name="27" href="#27">27</a><span class="c">// - Have user B unfollow user C again; should be idempotent.</span>
<a class="l" name="28" href="#28">28</a><span class="c">// - Fetch both users' "following and others" again; both should follow none.</span>
<a class="l" name="29" href="#29">29</a><span class="c">//</span>
<a class="hl" name="30" href="#30">30</a><span class="c">// - Create a user D.</span>
<a class="l" name="31" href="#31">31</a><span class="c">// - Have user B follow user C follow user D.</span>
<a class="l" name="32" href="#32">32</a><span class="c">// - Fetch all users' "following and others"; should be right.</span>
<a class="l" name="33" href="#33">33</a><span class="c">// - Delete user B.</span>
<a class="l" name="34" href="#34">34</a><span class="c">// - Fetch user C's and D's "following and others"; should be right.</span>
<a class="l" name="35" href="#35">35</a><span class="c">// - Delete user D.</span>
<a class="l" name="36" href="#36">36</a><span class="c">// - Fetch user C's "following and others"; should be right.</span>
<a class="l" name="37" href="#37">37</a><span class="c">// - Delete user C.</span>
<a class="l" name="38" href="#38">38</a><span class="c">//</span>
<a class="l" name="39" href="#39">39</a><span class="c">// NOTE: I struggle to translate this kind of test plan into BDD style tests.</span>
<a class="hl" name="40" href="#40">40</a><span class="c">// E.g. what am I "describing", and what should "it" do?? Help welcome! =)</span>
<a class="l" name="41" href="#41">41</a><span class="c">//</span>
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>
<a class="l" name="44" href="#44">44</a><b>var</b> <a class="xv" name="expect"/><a href="/source/s?refs=expect" class="xv">expect</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'chai'</span>).<a class="xv" name="expect"/><a href="/source/s?refs=expect" class="xv">expect</a>;
<a class="l" name="45" href="#45">45</a><b>var</b> <a class="xv" name="User"/><a href="/source/s?refs=User" class="xv">User</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'../../<a href="/source/s?path=/models/">models</a>/<a href="/source/s?path=/models/user">user</a>'</span>);
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a><span class="c">// Shared state:</span>
<a class="l" name="49" href="#49">49</a>
<a class="hl" name="50" href="#50">50</a><b>var</b> <a class="xv" name="INITIAL_USERS"/><a href="/source/s?refs=INITIAL_USERS" class="xv">INITIAL_USERS</a>;
<a class="l" name="51" href="#51">51</a><b>var</b> <a class="xv" name="USER_A"/><a href="/source/s?refs=USER_A" class="xv">USER_A</a>, <a href="/source/s?defs=USER_B">USER_B</a>, <a href="/source/s?defs=USER_C">USER_C</a>, <a href="/source/s?defs=USER_D">USER_D</a>;
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a><span class="c">// Helpers:</span>
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a><span class="c">/**
<a class="l" name="57" href="#57">57</a> * Asserts that the given object is a valid user model.
<a class="l" name="58" href="#58">58</a> * If an expected user model is given too (the second argument),
<a class="l" name="59" href="#59">59</a> * asserts that the given object represents the same user with the same data.
<a class="hl" name="60" href="#60">60</a> */</span>
<a class="l" name="61" href="#61">61</a><b>function</b> <a class="xf" name="expectUser"/><a href="/source/s?refs=expectUser" class="xf">expectUser</a>(<a href="/source/s?defs=obj">obj</a>, <a href="/source/s?defs=user">user</a>) {
<a class="l" name="62" href="#62">62</a>    <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=obj">obj</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.<a href="/source/s?defs=an">an</a>(<span class="s">'object'</span>);
<a class="l" name="63" href="#63">63</a>    <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=obj">obj</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.<a href="/source/s?defs=an">an</a>.<a href="/source/s?defs=instanceOf">instanceOf</a>(<a class="d" href="#User">User</a>);
<a class="l" name="64" href="#64">64</a>
<a class="l" name="65" href="#65">65</a>    <b>if</b> (<a href="/source/s?defs=user">user</a>) {
<a class="l" name="66" href="#66">66</a>        [<span class="s">'id'</span>, <span class="s">'name'</span>].<a href="/source/s?defs=forEach">forEach</a>(<b>function</b> (<a href="/source/s?defs=prop">prop</a>) {
<a class="l" name="67" href="#67">67</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=obj">obj</a>[<a href="/source/s?defs=prop">prop</a>]).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=equal">equal</a>(<a href="/source/s?defs=user">user</a>[<a href="/source/s?defs=prop">prop</a>]);
<a class="l" name="68" href="#68">68</a>        });
<a class="l" name="69" href="#69">69</a>    }
<a class="hl" name="70" href="#70">70</a>}
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a><span class="c">/**
<a class="l" name="73" href="#73">73</a> * Asserts that the given array of users contains the given user,
<a class="l" name="74" href="#74">74</a> * exactly and only once.
<a class="l" name="75" href="#75">75</a> */</span>
<a class="l" name="76" href="#76">76</a><b>function</b> <a class="xf" name="expectUsersToContain"/><a href="/source/s?refs=expectUsersToContain" class="xf">expectUsersToContain</a>(<a href="/source/s?defs=users">users</a>, <a href="/source/s?defs=expUser">expUser</a>) {
<a class="l" name="77" href="#77">77</a>    <b>var</b> <a href="/source/s?defs=found">found</a> = <b>false</b>;
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>    <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=users">users</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.<a href="/source/s?defs=an">an</a>(<span class="s">'array'</span>);
<a class="hl" name="80" href="#80">80</a>    <a href="/source/s?defs=users">users</a>.<a href="/source/s?defs=forEach">forEach</a>(<b>function</b> (<a href="/source/s?defs=actUser">actUser</a>) {
<a class="l" name="81" href="#81">81</a>        <b>if</b> (<a href="/source/s?defs=actUser">actUser</a>.<a href="/source/s?defs=id">id</a> === <a href="/source/s?defs=expUser">expUser</a>.<a href="/source/s?defs=id">id</a>) {
<a class="l" name="82" href="#82">82</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=found">found</a>, <span class="s">'User already found'</span>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=equal">equal</a>(<b>false</b>);
<a class="l" name="83" href="#83">83</a>            <a class="d" href="#expectUser">expectUser</a>(<a href="/source/s?defs=actUser">actUser</a>, <a href="/source/s?defs=expUser">expUser</a>);
<a class="l" name="84" href="#84">84</a>            <a href="/source/s?defs=found">found</a> = <b>true</b>;
<a class="l" name="85" href="#85">85</a>        }
<a class="l" name="86" href="#86">86</a>    });
<a class="l" name="87" href="#87">87</a>    <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=found">found</a>, <span class="s">'User not found'</span>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=equal">equal</a>(<b>true</b>);
<a class="l" name="88" href="#88">88</a>}
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a><span class="c">/**
<a class="l" name="91" href="#91">91</a> * Asserts that the given array of users does *not* contain the given user.
<a class="l" name="92" href="#92">92</a> */</span>
<a class="l" name="93" href="#93">93</a><b>function</b> <a class="xf" name="expectUsersToNotContain"/><a href="/source/s?refs=expectUsersToNotContain" class="xf">expectUsersToNotContain</a>(<a href="/source/s?defs=users">users</a>, <a href="/source/s?defs=expUser">expUser</a>) {
<a class="l" name="94" href="#94">94</a>    <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=users">users</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.<a href="/source/s?defs=an">an</a>(<span class="s">'array'</span>);
<a class="l" name="95" href="#95">95</a>    <a href="/source/s?defs=users">users</a>.<a href="/source/s?defs=forEach">forEach</a>(<b>function</b> (<a href="/source/s?defs=actUser">actUser</a>) {
<a class="l" name="96" href="#96">96</a>        <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=actUser">actUser</a>.<a href="/source/s?defs=id">id</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=not">not</a>.<a href="/source/s?defs=equal">equal</a>(<a href="/source/s?defs=expUser">expUser</a>.<a href="/source/s?defs=id">id</a>);
<a class="l" name="97" href="#97">97</a>    });
<a class="l" name="98" href="#98">98</a>}
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a><span class="c">/**
<a class="l" name="101" href="#101">101</a> * Fetches the given user's "following and others", and asserts that it
<a class="l" name="102" href="#102">102</a> * reflects the given list of expected following and expected others.
<a class="l" name="103" href="#103">103</a> * The expected following is expected to be a complete list, while the
<a class="l" name="104" href="#104">104</a> * expected others may be a subset of all users.
<a class="l" name="105" href="#105">105</a> * Calls the given callback (err, following, others) when complete.
<a class="l" name="106" href="#106">106</a> */</span>
<a class="l" name="107" href="#107">107</a><b>function</b> <a class="xf" name="expectUserToFollow"/><a href="/source/s?refs=expectUserToFollow" class="xf">expectUserToFollow</a>(<a href="/source/s?defs=user">user</a>, <a href="/source/s?defs=expFollowing">expFollowing</a>, <a href="/source/s?defs=expOthers">expOthers</a>, <a href="/source/s?defs=callback">callback</a>) {
<a class="l" name="108" href="#108">108</a>    <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=getFollowingAndOthers">getFollowingAndOthers</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=actFollowing">actFollowing</a>, <a href="/source/s?defs=actOthers">actOthers</a>) {
<a class="l" name="109" href="#109">109</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=callback">callback</a>(<a href="/source/s?defs=err">err</a>);
<a class="hl" name="110" href="#110">110</a>
<a class="l" name="111" href="#111">111</a>        <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=actFollowing">actFollowing</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.<a href="/source/s?defs=an">an</a>(<span class="s">'array'</span>);
<a class="l" name="112" href="#112">112</a>        <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=actFollowing">actFollowing</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=have">have</a>.<a href="/source/s?defs=length">length</a>(<a href="/source/s?defs=expFollowing">expFollowing</a>.<a href="/source/s?defs=length">length</a>);
<a class="l" name="113" href="#113">113</a>        <a href="/source/s?defs=expFollowing">expFollowing</a>.<a href="/source/s?defs=forEach">forEach</a>(<b>function</b> (<a href="/source/s?defs=expFollowingUser">expFollowingUser</a>) {
<a class="l" name="114" href="#114">114</a>            <a class="d" href="#expectUsersToContain">expectUsersToContain</a>(<a href="/source/s?defs=actFollowing">actFollowing</a>, <a href="/source/s?defs=expFollowingUser">expFollowingUser</a>);
<a class="l" name="115" href="#115">115</a>        });
<a class="l" name="116" href="#116">116</a>        <a href="/source/s?defs=expOthers">expOthers</a>.<a href="/source/s?defs=forEach">forEach</a>(<b>function</b> (<a href="/source/s?defs=expOtherUser">expOtherUser</a>) {
<a class="l" name="117" href="#117">117</a>            <a class="d" href="#expectUsersToNotContain">expectUsersToNotContain</a>(<a href="/source/s?defs=actFollowing">actFollowing</a>, <a href="/source/s?defs=expOtherUser">expOtherUser</a>);
<a class="l" name="118" href="#118">118</a>        });
<a class="l" name="119" href="#119">119</a>
<a class="hl" name="120" href="#120">120</a>        <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=actOthers">actOthers</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.<a href="/source/s?defs=an">an</a>(<span class="s">'array'</span>);
<a class="l" name="121" href="#121">121</a>        <a href="/source/s?defs=expOthers">expOthers</a>.<a href="/source/s?defs=forEach">forEach</a>(<b>function</b> (<a href="/source/s?defs=expOtherUser">expOtherUser</a>) {
<a class="l" name="122" href="#122">122</a>            <a class="d" href="#expectUsersToContain">expectUsersToContain</a>(<a href="/source/s?defs=actOthers">actOthers</a>, <a href="/source/s?defs=expOtherUser">expOtherUser</a>);
<a class="l" name="123" href="#123">123</a>        });
<a class="l" name="124" href="#124">124</a>        <a href="/source/s?defs=expFollowing">expFollowing</a>.<a href="/source/s?defs=forEach">forEach</a>(<b>function</b> (<a href="/source/s?defs=expFollowingUser">expFollowingUser</a>) {
<a class="l" name="125" href="#125">125</a>            <a class="d" href="#expectUsersToNotContain">expectUsersToNotContain</a>(<a href="/source/s?defs=actOthers">actOthers</a>, <a href="/source/s?defs=expFollowingUser">expFollowingUser</a>);
<a class="l" name="126" href="#126">126</a>        });
<a class="l" name="127" href="#127">127</a>
<a class="l" name="128" href="#128">128</a>        <span class="c">// and neither list should contain the user itself:</span>
<a class="l" name="129" href="#129">129</a>        <a class="d" href="#expectUsersToNotContain">expectUsersToNotContain</a>(<a href="/source/s?defs=actFollowing">actFollowing</a>, <a href="/source/s?defs=user">user</a>);
<a class="hl" name="130" href="#130">130</a>        <a class="d" href="#expectUsersToNotContain">expectUsersToNotContain</a>(<a href="/source/s?defs=actOthers">actOthers</a>, <a href="/source/s?defs=user">user</a>);
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>        <b>return</b> <a href="/source/s?defs=callback">callback</a>(<b>null</b>, <a href="/source/s?defs=actFollowing">actFollowing</a>, <a href="/source/s?defs=actOthers">actOthers</a>);
<a class="l" name="133" href="#133">133</a>    });
<a class="l" name="134" href="#134">134</a>}
<a class="l" name="135" href="#135">135</a>
<a class="l" name="136" href="#136">136</a>
<a class="l" name="137" href="#137">137</a><span class="c">// Tests:</span>
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a><a href="/source/s?defs=describe">describe</a>(<span class="s">'User models:'</span>, <b>function</b> () {
<a class="hl" name="140" href="#140">140</a>
<a class="l" name="141" href="#141">141</a>    <span class="c">// Single user CRUD:</span>
<a class="l" name="142" href="#142">142</a>
<a class="l" name="143" href="#143">143</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'List initial users'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="144" href="#144">144</a>        <a class="d" href="#User">User</a>.<a href="/source/s?defs=getAll">getAll</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=users">users</a>) {
<a class="l" name="145" href="#145">145</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="146" href="#146">146</a>
<a class="l" name="147" href="#147">147</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=users">users</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.<a href="/source/s?defs=an">an</a>(<span class="s">'array'</span>);
<a class="l" name="148" href="#148">148</a>            <a href="/source/s?defs=users">users</a>.<a href="/source/s?defs=forEach">forEach</a>(<b>function</b> (<a href="/source/s?defs=user">user</a>) {
<a class="l" name="149" href="#149">149</a>                <a class="d" href="#expectUser">expectUser</a>(<a href="/source/s?defs=user">user</a>);
<a class="hl" name="150" href="#150">150</a>            });
<a class="l" name="151" href="#151">151</a>
<a class="l" name="152" href="#152">152</a>            <a class="d" href="#INITIAL_USERS">INITIAL_USERS</a> = <a href="/source/s?defs=users">users</a>;
<a class="l" name="153" href="#153">153</a>            <b>return</b> <a href="/source/s?defs=next">next</a>();
<a class="l" name="154" href="#154">154</a>        });
<a class="l" name="155" href="#155">155</a>    });
<a class="l" name="156" href="#156">156</a>
<a class="l" name="157" href="#157">157</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Create user A'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="158" href="#158">158</a>        <b>var</b> <a href="/source/s?defs=name">name</a> = <span class="s">'Test User A'</span>;
<a class="l" name="159" href="#159">159</a>        <a class="d" href="#User">User</a>.<a href="/source/s?defs=create">create</a>({<a href="/source/s?defs=name">name</a>: <a href="/source/s?defs=name">name</a>}, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="hl" name="160" href="#160">160</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="161" href="#161">161</a>
<a class="l" name="162" href="#162">162</a>            <a class="d" href="#expectUser">expectUser</a>(<a href="/source/s?defs=user">user</a>);
<a class="l" name="163" href="#163">163</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=id">id</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.a(<span class="s">'number'</span>);
<a class="l" name="164" href="#164">164</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=name">name</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.<a href="/source/s?defs=equal">equal</a>(<a href="/source/s?defs=name">name</a>);
<a class="l" name="165" href="#165">165</a>
<a class="l" name="166" href="#166">166</a>            <a class="d" href="#USER_A">USER_A</a> = <a href="/source/s?defs=user">user</a>;
<a class="l" name="167" href="#167">167</a>            <b>return</b> <a href="/source/s?defs=next">next</a>();
<a class="l" name="168" href="#168">168</a>        });
<a class="l" name="169" href="#169">169</a>    });
<a class="hl" name="170" href="#170">170</a>
<a class="l" name="171" href="#171">171</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Fetch user A'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="172" href="#172">172</a>        <a class="d" href="#User">User</a>.<a href="/source/s?defs=get">get</a>(<a class="d" href="#USER_A">USER_A</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="l" name="173" href="#173">173</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="174" href="#174">174</a>            <a class="d" href="#expectUser">expectUser</a>(<a href="/source/s?defs=user">user</a>, <a class="d" href="#USER_A">USER_A</a>);
<a class="l" name="175" href="#175">175</a>            <b>return</b> <a href="/source/s?defs=next">next</a>();
<a class="l" name="176" href="#176">176</a>        });
<a class="l" name="177" href="#177">177</a>    });
<a class="l" name="178" href="#178">178</a>
<a class="l" name="179" href="#179">179</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'List users again'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="hl" name="180" href="#180">180</a>        <a class="d" href="#User">User</a>.<a href="/source/s?defs=getAll">getAll</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=users">users</a>) {
<a class="l" name="181" href="#181">181</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="182" href="#182">182</a>
<a class="l" name="183" href="#183">183</a>            <span class="c">// the order isn't part of the contract, so we just test that the</span>
<a class="l" name="184" href="#184">184</a>            <span class="c">// new array is one longer than the initial, and contains user A.</span>
<a class="l" name="185" href="#185">185</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=users">users</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.<a href="/source/s?defs=an">an</a>(<span class="s">'array'</span>);
<a class="l" name="186" href="#186">186</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=users">users</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=have">have</a>.<a href="/source/s?defs=length">length</a>(<a class="d" href="#INITIAL_USERS">INITIAL_USERS</a>.<a href="/source/s?defs=length">length</a> + <span class="n">1</span>);
<a class="l" name="187" href="#187">187</a>            <a class="d" href="#expectUsersToContain">expectUsersToContain</a>(<a href="/source/s?defs=users">users</a>, <a class="d" href="#USER_A">USER_A</a>);
<a class="l" name="188" href="#188">188</a>
<a class="l" name="189" href="#189">189</a>            <b>return</b> <a href="/source/s?defs=next">next</a>();
<a class="hl" name="190" href="#190">190</a>        });
<a class="l" name="191" href="#191">191</a>    });
<a class="l" name="192" href="#192">192</a>
<a class="l" name="193" href="#193">193</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Update user A'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="194" href="#194">194</a>        <a class="d" href="#USER_A">USER_A</a>.<a href="/source/s?defs=name">name</a> += <span class="s">' (edited)'</span>;
<a class="l" name="195" href="#195">195</a>        <a class="d" href="#USER_A">USER_A</a>.<a href="/source/s?defs=save">save</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="196" href="#196">196</a>            <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="197" href="#197">197</a>        });
<a class="l" name="198" href="#198">198</a>    });
<a class="l" name="199" href="#199">199</a>
<a class="hl" name="200" href="#200">200</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Fetch user A again'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="201" href="#201">201</a>        <a class="d" href="#User">User</a>.<a href="/source/s?defs=get">get</a>(<a class="d" href="#USER_A">USER_A</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="l" name="202" href="#202">202</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="203" href="#203">203</a>            <a class="d" href="#expectUser">expectUser</a>(<a href="/source/s?defs=user">user</a>, <a class="d" href="#USER_A">USER_A</a>);
<a class="l" name="204" href="#204">204</a>            <b>return</b> <a href="/source/s?defs=next">next</a>();
<a class="l" name="205" href="#205">205</a>        });
<a class="l" name="206" href="#206">206</a>    });
<a class="l" name="207" href="#207">207</a>
<a class="l" name="208" href="#208">208</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Delete user A'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="209" href="#209">209</a>        <a class="d" href="#USER_A">USER_A</a>.<a href="/source/s?defs=del">del</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="hl" name="210" href="#210">210</a>            <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="211" href="#211">211</a>        });
<a class="l" name="212" href="#212">212</a>    });
<a class="l" name="213" href="#213">213</a>
<a class="l" name="214" href="#214">214</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Attempt to fetch user A again'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="215" href="#215">215</a>        <a class="d" href="#User">User</a>.<a href="/source/s?defs=get">get</a>(<a class="d" href="#USER_A">USER_A</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="l" name="216" href="#216">216</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=user">user</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=not">not</a>.<a href="/source/s?defs=exist">exist</a>;  <span class="c">// i.e. null or undefined</span>
<a class="l" name="217" href="#217">217</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=err">err</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.<a href="/source/s?defs=an">an</a>(<span class="s">'object'</span>);
<a class="l" name="218" href="#218">218</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=err">err</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.<a href="/source/s?defs=an">an</a>.<a href="/source/s?defs=instanceOf">instanceOf</a>(<a href="/source/s?defs=Error">Error</a>);
<a class="l" name="219" href="#219">219</a>            <b>return</b> <a href="/source/s?defs=next">next</a>();
<a class="hl" name="220" href="#220">220</a>        });
<a class="l" name="221" href="#221">221</a>    });
<a class="l" name="222" href="#222">222</a>
<a class="l" name="223" href="#223">223</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'List users again'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="224" href="#224">224</a>        <a class="d" href="#User">User</a>.<a href="/source/s?defs=getAll">getAll</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=users">users</a>) {
<a class="l" name="225" href="#225">225</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="226" href="#226">226</a>
<a class="l" name="227" href="#227">227</a>            <span class="c">// like before, we just test that this array is now back to the</span>
<a class="l" name="228" href="#228">228</a>            <span class="c">// initial length, and *doesn't* contain user A.</span>
<a class="l" name="229" href="#229">229</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=users">users</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.<a href="/source/s?defs=an">an</a>(<span class="s">'array'</span>);
<a class="hl" name="230" href="#230">230</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=users">users</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=have">have</a>.<a href="/source/s?defs=length">length</a>(<a class="d" href="#INITIAL_USERS">INITIAL_USERS</a>.<a href="/source/s?defs=length">length</a>);
<a class="l" name="231" href="#231">231</a>            <a class="d" href="#expectUsersToNotContain">expectUsersToNotContain</a>(<a href="/source/s?defs=users">users</a>, <a class="d" href="#USER_A">USER_A</a>);
<a class="l" name="232" href="#232">232</a>
<a class="l" name="233" href="#233">233</a>            <b>return</b> <a href="/source/s?defs=next">next</a>();
<a class="l" name="234" href="#234">234</a>        });
<a class="l" name="235" href="#235">235</a>    });
<a class="l" name="236" href="#236">236</a>
<a class="l" name="237" href="#237">237</a>    <span class="c">// Two-user following:</span>
<a class="l" name="238" href="#238">238</a>
<a class="l" name="239" href="#239">239</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Create users B and C'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="hl" name="240" href="#240">240</a>        <b>var</b> <a href="/source/s?defs=nameB">nameB</a> = <span class="s">'Test User B'</span>;
<a class="l" name="241" href="#241">241</a>        <b>var</b> <a href="/source/s?defs=nameC">nameC</a> = <span class="s">'Test User C'</span>;
<a class="l" name="242" href="#242">242</a>
<a class="l" name="243" href="#243">243</a>        <b>function</b> <a href="/source/s?defs=callback">callback</a>(<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="l" name="244" href="#244">244</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="245" href="#245">245</a>
<a class="l" name="246" href="#246">246</a>            <a class="d" href="#expectUser">expectUser</a>(<a href="/source/s?defs=user">user</a>);
<a class="l" name="247" href="#247">247</a>
<a class="l" name="248" href="#248">248</a>            <b>switch</b> (<a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=name">name</a>) {
<a class="l" name="249" href="#249">249</a>                <b>case</b> <a href="/source/s?defs=nameB">nameB</a>:
<a class="hl" name="250" href="#250">250</a>                    <a href="/source/s?defs=USER_B">USER_B</a> = <a href="/source/s?defs=user">user</a>;
<a class="l" name="251" href="#251">251</a>                    <b>break</b>;
<a class="l" name="252" href="#252">252</a>                <b>case</b> <a href="/source/s?defs=nameC">nameC</a>:
<a class="l" name="253" href="#253">253</a>                    <a href="/source/s?defs=USER_C">USER_C</a> = <a href="/source/s?defs=user">user</a>;
<a class="l" name="254" href="#254">254</a>                    <b>break</b>;
<a class="l" name="255" href="#255">255</a>                <b>default</b>:
<a class="l" name="256" href="#256">256</a>                    <span class="c">// trigger an assertion error:</span>
<a class="l" name="257" href="#257">257</a>                    <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=name">name</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=equal">equal</a>(<a href="/source/s?defs=nameB">nameB</a>);
<a class="l" name="258" href="#258">258</a>            }
<a class="l" name="259" href="#259">259</a>
<a class="hl" name="260" href="#260">260</a>            <b>if</b> (<a href="/source/s?defs=USER_B">USER_B</a> &amp;&amp; <a href="/source/s?defs=USER_C">USER_C</a>) {
<a class="l" name="261" href="#261">261</a>                <b>return</b> <a href="/source/s?defs=next">next</a>();
<a class="l" name="262" href="#262">262</a>            }
<a class="l" name="263" href="#263">263</a>        }
<a class="l" name="264" href="#264">264</a>
<a class="l" name="265" href="#265">265</a>        <a class="d" href="#User">User</a>.<a href="/source/s?defs=create">create</a>({<a href="/source/s?defs=name">name</a>: <a href="/source/s?defs=nameB">nameB</a>}, <a href="/source/s?defs=callback">callback</a>);
<a class="l" name="266" href="#266">266</a>        <a class="d" href="#User">User</a>.<a href="/source/s?defs=create">create</a>({<a href="/source/s?defs=name">name</a>: <a href="/source/s?defs=nameC">nameC</a>}, <a href="/source/s?defs=callback">callback</a>);
<a class="l" name="267" href="#267">267</a>    });
<a class="l" name="268" href="#268">268</a>
<a class="l" name="269" href="#269">269</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Fetch user B&#226;&#8364;&#8482;s&#194;&#160;&#226;&#8364;&#339;following and others&#226;&#8364;&#65533;'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="hl" name="270" href="#270">270</a>        <a class="d" href="#expectUserToFollow">expectUserToFollow</a>(<a href="/source/s?defs=USER_B">USER_B</a>, [], [<a href="/source/s?defs=USER_C">USER_C</a>], <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=following">following</a>, <a href="/source/s?defs=others">others</a>) {
<a class="l" name="271" href="#271">271</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="272" href="#272">272</a>
<a class="l" name="273" href="#273">273</a>            <span class="c">// our helper tests most things; we just test the length of others:</span>
<a class="l" name="274" href="#274">274</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=others">others</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=have">have</a>.<a href="/source/s?defs=length">length</a>(<a class="d" href="#INITIAL_USERS">INITIAL_USERS</a>.<a href="/source/s?defs=length">length</a> + <span class="n">1</span>);
<a class="l" name="275" href="#275">275</a>
<a class="l" name="276" href="#276">276</a>            <b>return</b> <a href="/source/s?defs=next">next</a>();
<a class="l" name="277" href="#277">277</a>        });
<a class="l" name="278" href="#278">278</a>    });
<a class="l" name="279" href="#279">279</a>
<a class="hl" name="280" href="#280">280</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Fetch user C&#226;&#8364;&#8482;s&#194;&#160;&#226;&#8364;&#339;following and others&#226;&#8364;&#65533;'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="281" href="#281">281</a>        <a class="d" href="#expectUserToFollow">expectUserToFollow</a>(<a href="/source/s?defs=USER_C">USER_C</a>, [], [<a href="/source/s?defs=USER_B">USER_B</a>], <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=following">following</a>, <a href="/source/s?defs=others">others</a>) {
<a class="l" name="282" href="#282">282</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="283" href="#283">283</a>
<a class="l" name="284" href="#284">284</a>            <span class="c">// our helper tests most things; we just test the length of others:</span>
<a class="l" name="285" href="#285">285</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=others">others</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=have">have</a>.<a href="/source/s?defs=length">length</a>(<a class="d" href="#INITIAL_USERS">INITIAL_USERS</a>.<a href="/source/s?defs=length">length</a> + <span class="n">1</span>);
<a class="l" name="286" href="#286">286</a>
<a class="l" name="287" href="#287">287</a>            <b>return</b> <a href="/source/s?defs=next">next</a>();
<a class="l" name="288" href="#288">288</a>        });
<a class="l" name="289" href="#289">289</a>    });
<a class="hl" name="290" href="#290">290</a>
<a class="l" name="291" href="#291">291</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Have user B follow user C'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="292" href="#292">292</a>        <a href="/source/s?defs=USER_B">USER_B</a>.<a href="/source/s?defs=follow">follow</a>(<a href="/source/s?defs=USER_C">USER_C</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="293" href="#293">293</a>            <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="294" href="#294">294</a>        });
<a class="l" name="295" href="#295">295</a>    });
<a class="l" name="296" href="#296">296</a>
<a class="l" name="297" href="#297">297</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Have user B follow user C again'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="298" href="#298">298</a>        <a href="/source/s?defs=USER_B">USER_B</a>.<a href="/source/s?defs=follow">follow</a>(<a href="/source/s?defs=USER_C">USER_C</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="299" href="#299">299</a>            <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="hl" name="300" href="#300">300</a>        });
<a class="l" name="301" href="#301">301</a>    });
<a class="l" name="302" href="#302">302</a>
<a class="l" name="303" href="#303">303</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Fetch user B&#226;&#8364;&#8482;s&#194;&#160;&#226;&#8364;&#339;following and others&#226;&#8364;&#65533;'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="304" href="#304">304</a>        <a class="d" href="#expectUserToFollow">expectUserToFollow</a>(<a href="/source/s?defs=USER_B">USER_B</a>, [<a href="/source/s?defs=USER_C">USER_C</a>], [], <a href="/source/s?defs=next">next</a>);
<a class="l" name="305" href="#305">305</a>    });
<a class="l" name="306" href="#306">306</a>
<a class="l" name="307" href="#307">307</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Fetch user C&#226;&#8364;&#8482;s&#194;&#160;&#226;&#8364;&#339;following and others&#226;&#8364;&#65533;'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="308" href="#308">308</a>        <a class="d" href="#expectUserToFollow">expectUserToFollow</a>(<a href="/source/s?defs=USER_C">USER_C</a>, [], [<a href="/source/s?defs=USER_B">USER_B</a>], <a href="/source/s?defs=next">next</a>);
<a class="l" name="309" href="#309">309</a>    });
<a class="hl" name="310" href="#310">310</a>
<a class="l" name="311" href="#311">311</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Have user B unfollow user C'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="312" href="#312">312</a>        <a href="/source/s?defs=USER_B">USER_B</a>.<a href="/source/s?defs=unfollow">unfollow</a>(<a href="/source/s?defs=USER_C">USER_C</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="313" href="#313">313</a>            <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="314" href="#314">314</a>        });
<a class="l" name="315" href="#315">315</a>    });
<a class="l" name="316" href="#316">316</a>
<a class="l" name="317" href="#317">317</a>    <span class="c">// NOTE: skipping this actually causes the next two tests to fail!</span>
<a class="l" name="318" href="#318">318</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Have user B unfollow user C again'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="319" href="#319">319</a>        <a href="/source/s?defs=USER_B">USER_B</a>.<a href="/source/s?defs=unfollow">unfollow</a>(<a href="/source/s?defs=USER_C">USER_C</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="hl" name="320" href="#320">320</a>            <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="321" href="#321">321</a>        });
<a class="l" name="322" href="#322">322</a>    });
<a class="l" name="323" href="#323">323</a>
<a class="l" name="324" href="#324">324</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Fetch user B&#226;&#8364;&#8482;s&#194;&#160;&#226;&#8364;&#339;following and others&#226;&#8364;&#65533;'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="325" href="#325">325</a>        <a class="d" href="#expectUserToFollow">expectUserToFollow</a>(<a href="/source/s?defs=USER_B">USER_B</a>, [], [<a href="/source/s?defs=USER_C">USER_C</a>], <a href="/source/s?defs=next">next</a>);
<a class="l" name="326" href="#326">326</a>    });
<a class="l" name="327" href="#327">327</a>
<a class="l" name="328" href="#328">328</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Fetch user C&#226;&#8364;&#8482;s&#194;&#160;&#226;&#8364;&#339;following and others&#226;&#8364;&#65533;'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="329" href="#329">329</a>        <a class="d" href="#expectUserToFollow">expectUserToFollow</a>(<a href="/source/s?defs=USER_C">USER_C</a>, [], [<a href="/source/s?defs=USER_B">USER_B</a>], <a href="/source/s?defs=next">next</a>);
<a class="hl" name="330" href="#330">330</a>    });
<a class="l" name="331" href="#331">331</a>
<a class="l" name="332" href="#332">332</a>    <span class="c">// Multi-user-following deletions:</span>
<a class="l" name="333" href="#333">333</a>
<a class="l" name="334" href="#334">334</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Create user D'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="335" href="#335">335</a>        <b>var</b> <a href="/source/s?defs=name">name</a> = <span class="s">'Test User D'</span>;
<a class="l" name="336" href="#336">336</a>        <a class="d" href="#User">User</a>.<a href="/source/s?defs=create">create</a>({<a href="/source/s?defs=name">name</a>: <a href="/source/s?defs=name">name</a>}, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="l" name="337" href="#337">337</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="338" href="#338">338</a>
<a class="l" name="339" href="#339">339</a>            <a class="d" href="#expectUser">expectUser</a>(<a href="/source/s?defs=user">user</a>);
<a class="hl" name="340" href="#340">340</a>            <a class="d" href="#expect">expect</a>(<a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=name">name</a>).<a href="/source/s?defs=to">to</a>.<a href="/source/s?defs=be">be</a>.<a href="/source/s?defs=equal">equal</a>(<a href="/source/s?defs=name">name</a>);
<a class="l" name="341" href="#341">341</a>
<a class="l" name="342" href="#342">342</a>            <a href="/source/s?defs=USER_D">USER_D</a> = <a href="/source/s?defs=user">user</a>;
<a class="l" name="343" href="#343">343</a>            <b>return</b> <a href="/source/s?defs=next">next</a>();
<a class="l" name="344" href="#344">344</a>        });
<a class="l" name="345" href="#345">345</a>    });
<a class="l" name="346" href="#346">346</a>
<a class="l" name="347" href="#347">347</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Have user B follow user C follow user D'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="348" href="#348">348</a>        <b>var</b> <a href="/source/s?defs=remaining">remaining</a> = <span class="n">2</span>;
<a class="l" name="349" href="#349">349</a>
<a class="hl" name="350" href="#350">350</a>        <b>function</b> <a href="/source/s?defs=callback">callback</a>(<a href="/source/s?defs=err">err</a>) {
<a class="l" name="351" href="#351">351</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="352" href="#352">352</a>            <b>if</b> (--<a href="/source/s?defs=remaining">remaining</a> === <span class="n">0</span>) {
<a class="l" name="353" href="#353">353</a>                <a href="/source/s?defs=next">next</a>();
<a class="l" name="354" href="#354">354</a>            }
<a class="l" name="355" href="#355">355</a>        }
<a class="l" name="356" href="#356">356</a>
<a class="l" name="357" href="#357">357</a>        <a href="/source/s?defs=USER_B">USER_B</a>.<a href="/source/s?defs=follow">follow</a>(<a href="/source/s?defs=USER_C">USER_C</a>, <a href="/source/s?defs=callback">callback</a>);
<a class="l" name="358" href="#358">358</a>        <a href="/source/s?defs=USER_C">USER_C</a>.<a href="/source/s?defs=follow">follow</a>(<a href="/source/s?defs=USER_D">USER_D</a>, <a href="/source/s?defs=callback">callback</a>);
<a class="l" name="359" href="#359">359</a>    });
<a class="hl" name="360" href="#360">360</a>
<a class="l" name="361" href="#361">361</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Fetch all user&#226;&#8364;&#8482;s &#226;&#8364;&#339;following and others&#226;&#8364;&#65533;'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="362" href="#362">362</a>        <b>var</b> <a href="/source/s?defs=remaining">remaining</a> = <span class="n">3</span>;
<a class="l" name="363" href="#363">363</a>
<a class="l" name="364" href="#364">364</a>        <b>function</b> <a href="/source/s?defs=callback">callback</a>(<a href="/source/s?defs=err">err</a>) {
<a class="l" name="365" href="#365">365</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="366" href="#366">366</a>            <b>if</b> (--<a href="/source/s?defs=remaining">remaining</a> === <span class="n">0</span>) {
<a class="l" name="367" href="#367">367</a>                <a href="/source/s?defs=next">next</a>();
<a class="l" name="368" href="#368">368</a>            }
<a class="l" name="369" href="#369">369</a>        }
<a class="hl" name="370" href="#370">370</a>
<a class="l" name="371" href="#371">371</a>        <a class="d" href="#expectUserToFollow">expectUserToFollow</a>(<a href="/source/s?defs=USER_B">USER_B</a>, [<a href="/source/s?defs=USER_C">USER_C</a>], [<a href="/source/s?defs=USER_D">USER_D</a>], <a href="/source/s?defs=callback">callback</a>);
<a class="l" name="372" href="#372">372</a>        <a class="d" href="#expectUserToFollow">expectUserToFollow</a>(<a href="/source/s?defs=USER_C">USER_C</a>, [<a href="/source/s?defs=USER_D">USER_D</a>], [<a href="/source/s?defs=USER_B">USER_B</a>], <a href="/source/s?defs=callback">callback</a>);
<a class="l" name="373" href="#373">373</a>        <a class="d" href="#expectUserToFollow">expectUserToFollow</a>(<a href="/source/s?defs=USER_D">USER_D</a>, [], [<a href="/source/s?defs=USER_B">USER_B</a>, <a href="/source/s?defs=USER_C">USER_C</a>], <a href="/source/s?defs=callback">callback</a>);
<a class="l" name="374" href="#374">374</a>    });
<a class="l" name="375" href="#375">375</a>
<a class="l" name="376" href="#376">376</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Delete user B'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="377" href="#377">377</a>        <a href="/source/s?defs=USER_B">USER_B</a>.<a href="/source/s?defs=del">del</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="378" href="#378">378</a>            <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="379" href="#379">379</a>        });
<a class="hl" name="380" href="#380">380</a>    });
<a class="l" name="381" href="#381">381</a>
<a class="l" name="382" href="#382">382</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Fetch user C&#226;&#8364;&#8482;s and D&#226;&#8364;&#8482;s &#226;&#8364;&#339;following and others&#226;&#8364;&#65533;'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="383" href="#383">383</a>        <b>var</b> <a href="/source/s?defs=remaining">remaining</a> = <span class="n">2</span>;
<a class="l" name="384" href="#384">384</a>
<a class="l" name="385" href="#385">385</a>        <b>function</b> <a href="/source/s?defs=callback">callback</a>(<a href="/source/s?defs=err">err</a>) {
<a class="l" name="386" href="#386">386</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="387" href="#387">387</a>            <b>if</b> (--<a href="/source/s?defs=remaining">remaining</a> === <span class="n">0</span>) {
<a class="l" name="388" href="#388">388</a>                <a href="/source/s?defs=next">next</a>();
<a class="l" name="389" href="#389">389</a>            }
<a class="hl" name="390" href="#390">390</a>        }
<a class="l" name="391" href="#391">391</a>
<a class="l" name="392" href="#392">392</a>        <a class="d" href="#expectUserToFollow">expectUserToFollow</a>(<a href="/source/s?defs=USER_C">USER_C</a>, [<a href="/source/s?defs=USER_D">USER_D</a>], [], <a href="/source/s?defs=callback">callback</a>);
<a class="l" name="393" href="#393">393</a>        <a class="d" href="#expectUserToFollow">expectUserToFollow</a>(<a href="/source/s?defs=USER_D">USER_D</a>, [], [<a href="/source/s?defs=USER_C">USER_C</a>], <a href="/source/s?defs=callback">callback</a>);
<a class="l" name="394" href="#394">394</a>    });
<a class="l" name="395" href="#395">395</a>
<a class="l" name="396" href="#396">396</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Delete user D'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="397" href="#397">397</a>        <a href="/source/s?defs=USER_D">USER_D</a>.<a href="/source/s?defs=del">del</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="398" href="#398">398</a>            <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="399" href="#399">399</a>        });
<a class="hl" name="400" href="#400">400</a>    });
<a class="l" name="401" href="#401">401</a>
<a class="l" name="402" href="#402">402</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Fetch user C&#226;&#8364;&#8482;s &#226;&#8364;&#339;following and others&#226;&#8364;&#65533;'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="403" href="#403">403</a>        <a class="d" href="#expectUserToFollow">expectUserToFollow</a>(<a href="/source/s?defs=USER_C">USER_C</a>, [], [], <a href="/source/s?defs=next">next</a>);
<a class="l" name="404" href="#404">404</a>    });
<a class="l" name="405" href="#405">405</a>
<a class="l" name="406" href="#406">406</a>    <a href="/source/s?defs=it">it</a>(<span class="s">'Delete user C'</span>, <b>function</b> (<a href="/source/s?defs=next">next</a>) {
<a class="l" name="407" href="#407">407</a>        <a href="/source/s?defs=USER_C">USER_C</a>.<a href="/source/s?defs=del">del</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="408" href="#408">408</a>            <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="409" href="#409">409</a>        });
<a class="hl" name="410" href="#410">410</a>    });
<a class="l" name="411" href="#411">411</a>
<a class="l" name="412" href="#412">412</a>});
<a class="l" name="413" href="#413">413</a>