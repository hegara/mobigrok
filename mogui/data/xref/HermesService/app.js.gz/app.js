<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["app",19],["bodyParser",15],["errorHandler",17],["express",6],["favicon",11],["http",8],["logger",12],["methodOverride",13],["multer",16],["path",9],["routes",7],["session",14]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>
<a class="l" name="2" href="#2">2</a><span class="c">/**
<a class="l" name="3" href="#3">3</a> * Module dependencies.
<a class="l" name="4" href="#4">4</a> */</span>
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a><b>var</b> <a class="xv" name="express"/><a href="/source/s?refs=express" class="xv">express</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'express'</span>);
<a class="l" name="7" href="#7">7</a><b>var</b> <a class="xv" name="routes"/><a href="/source/s?refs=routes" class="xv">routes</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'./routes'</span>);
<a class="l" name="8" href="#8">8</a><b>var</b> <a class="xv" name="http"/><a href="/source/s?refs=http" class="xv">http</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'http'</span>);
<a class="l" name="9" href="#9">9</a><b>var</b> <a class="xv" name="path"/><a href="/source/s?refs=path" class="xv">path</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'path'</span>);
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a><b>var</b> <a class="xv" name="favicon"/><a href="/source/s?refs=favicon" class="xv">favicon</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'serve-favicon'</span>);
<a class="l" name="12" href="#12">12</a><b>var</b> <a class="xv" name="logger"/><a href="/source/s?refs=logger" class="xv">logger</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'morgan'</span>);
<a class="l" name="13" href="#13">13</a><b>var</b> <a class="xv" name="methodOverride"/><a href="/source/s?refs=methodOverride" class="xv">methodOverride</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'method-override'</span>);
<a class="l" name="14" href="#14">14</a><b>var</b> <a class="xv" name="session"/><a href="/source/s?refs=session" class="xv">session</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'express-session'</span>);
<a class="l" name="15" href="#15">15</a><b>var</b> <a class="xv" name="bodyParser"/><a href="/source/s?refs=bodyParser" class="xv">bodyParser</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'body-parser'</span>);
<a class="l" name="16" href="#16">16</a><b>var</b> <a class="xv" name="multer"/><a href="/source/s?refs=multer" class="xv">multer</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'multer'</span>);
<a class="l" name="17" href="#17">17</a><b>var</b> <a class="xv" name="errorHandler"/><a href="/source/s?refs=errorHandler" class="xv">errorHandler</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'errorhandler'</span>);
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a><b>var</b> <a class="xv" name="app"/><a href="/source/s?refs=app" class="xv">app</a> = <a class="d" href="#express">express</a>();
<a class="hl" name="20" href="#20">20</a>
<a class="l" name="21" href="#21">21</a><span class="c">// all environments</span>
<a class="l" name="22" href="#22">22</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=set">set</a>(<span class="s">'port'</span>, <a href="/source/s?defs=process">process</a>.<a href="/source/s?defs=env">env</a>.<a href="/source/s?defs=PORT">PORT</a> || <span class="n">3000</span>);
<a class="l" name="23" href="#23">23</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=set">set</a>(<span class="s">'views'</span>, <a class="d" href="#path">path</a>.<a href="/source/s?defs=join">join</a>(<a href="/source/s?defs=__dirname">__dirname</a>, <span class="s">'views'</span>));
<a class="l" name="24" href="#24">24</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=set">set</a>(<span class="s">'view engine'</span>, <span class="s">'jade'</span>);
<a class="l" name="25" href="#25">25</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=use">use</a>(<a class="d" href="#favicon">favicon</a>(<a class="d" href="#path">path</a>.<a href="/source/s?defs=join">join</a>(<a href="/source/s?defs=__dirname">__dirname</a>, <span class="s">'/<a href="/source/s?path=/public/">public</a>/<a href="/source/s?path=/public/favicon.ico">favicon.ico</a>'</span>)));
<a class="l" name="26" href="#26">26</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=use">use</a>(<a class="d" href="#logger">logger</a>(<span class="s">'dev'</span>));
<a class="l" name="27" href="#27">27</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=use">use</a>(<a class="d" href="#methodOverride">methodOverride</a>());
<a class="l" name="28" href="#28">28</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=use">use</a>(<a class="d" href="#session">session</a>({ <a href="/source/s?defs=resave">resave</a>: <b>true</b>,
<a class="l" name="29" href="#29">29</a>                  <a href="/source/s?defs=saveUninitialized">saveUninitialized</a>: <b>true</b>,
<a class="hl" name="30" href="#30">30</a>                  <a href="/source/s?defs=secret">secret</a>: <span class="s">'uwotm8'</span> }));
<a class="l" name="31" href="#31">31</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=use">use</a>(<a class="d" href="#bodyParser">bodyParser</a>.<a href="/source/s?defs=json">json</a>());
<a class="l" name="32" href="#32">32</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=use">use</a>(<a class="d" href="#bodyParser">bodyParser</a>.<a href="/source/s?defs=urlencoded">urlencoded</a>({ <a href="/source/s?defs=extended">extended</a>: <b>true</b> }));
<a class="l" name="33" href="#33">33</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=use">use</a>(<a class="d" href="#multer">multer</a>());
<a class="l" name="34" href="#34">34</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=use">use</a>(<a class="d" href="#express">express</a>.<b>static</b>(<a class="d" href="#path">path</a>.<a href="/source/s?defs=join">join</a>(<a href="/source/s?defs=__dirname">__dirname</a>, <span class="s">'public'</span>)));
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a><span class="c">// development only</span>
<a class="l" name="37" href="#37">37</a><b>if</b> (<span class="s">'development'</span> == <a class="d" href="#app">app</a>.<a href="/source/s?defs=get">get</a>(<span class="s">'env'</span>)) {
<a class="l" name="38" href="#38">38</a>  <a class="d" href="#app">app</a>.<a href="/source/s?defs=use">use</a>(<a class="d" href="#errorHandler">errorHandler</a>());
<a class="l" name="39" href="#39">39</a>}
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=locals">locals</a>.<a href="/source/s?defs=title">title</a> = <span class="s">'mobigrok'</span>;<span class="c">// default title</span>
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a><span class="c">// Routes</span>
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=get">get</a>(<span class="s">'/'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=site">site</a>.<a href="/source/s?defs=index">index</a>);
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=get">get</a>(<span class="s">'/users'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=users">users</a>.<a href="/source/s?defs=list">list</a>);
<a class="l" name="48" href="#48">48</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=post">post</a>(<span class="s">'/users'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=users">users</a>.<a href="/source/s?defs=create">create</a>);
<a class="l" name="49" href="#49">49</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=get">get</a>(<span class="s">'/users/:id'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=users">users</a>.<a href="/source/s?defs=show">show</a>);
<a class="hl" name="50" href="#50">50</a><a class="d" href="#app">app</a>.<b>delete</b>(<span class="s">'/users/:id'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=users">users</a>.<a href="/source/s?defs=del">del</a>);
<a class="l" name="51" href="#51">51</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=post">post</a>(<span class="s">'/users/:id'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=users">users</a>.<a href="/source/s?defs=edit">edit</a>);
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=post">post</a>(<span class="s">'/users/:<a href="/source/s?path=id/">id</a>/<a href="/source/s?path=id/follow">follow</a>'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=users">users</a>.<a href="/source/s?defs=follow">follow</a>);
<a class="l" name="54" href="#54">54</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=post">post</a>(<span class="s">'/users/:<a href="/source/s?path=id/">id</a>/<a href="/source/s?path=id/unfollow">unfollow</a>'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=users">users</a>.<a href="/source/s?defs=unfollow">unfollow</a>);
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=post">post</a>(<span class="s">'/users/:<a href="/source/s?path=id/">id</a>/<a href="/source/s?path=id/enlist">enlist</a>'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=users">users</a>.<a href="/source/s?defs=enlist">enlist</a>);
<a class="l" name="57" href="#57">57</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=post">post</a>(<span class="s">'/users/:<a href="/source/s?path=id/">id</a>/<a href="/source/s?path=id/unlist">unlist</a>'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=users">users</a>.<a href="/source/s?defs=unlist">unlist</a>);
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=get">get</a>(<span class="s">'/sources'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=sources">sources</a>.<a href="/source/s?defs=list">list</a>);
<a class="hl" name="60" href="#60">60</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=post">post</a>(<span class="s">'/sources'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=sources">sources</a>.<a href="/source/s?defs=create">create</a>);
<a class="l" name="61" href="#61">61</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=get">get</a>(<span class="s">'/sources/:id'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=sources">sources</a>.<a href="/source/s?defs=show">show</a>);
<a class="l" name="62" href="#62">62</a><a class="d" href="#app">app</a>.<b>delete</b>(<span class="s">'/sources/:id'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=sources">sources</a>.<a href="/source/s?defs=del">del</a>);
<a class="l" name="63" href="#63">63</a><a class="d" href="#app">app</a>.<a href="/source/s?defs=post">post</a>(<span class="s">'/sources/:id'</span>, <a class="d" href="#routes">routes</a>.<a href="/source/s?defs=sources">sources</a>.<a href="/source/s?defs=edit">edit</a>);
<a class="l" name="64" href="#64">64</a>
<a class="l" name="65" href="#65">65</a><a class="d" href="#http">http</a>.<a href="/source/s?defs=createServer">createServer</a>(<a class="d" href="#app">app</a>).<a href="/source/s?defs=listen">listen</a>(<a class="d" href="#app">app</a>.<a href="/source/s?defs=get">get</a>(<span class="s">'port'</span>), <b>function</b>(){
<a class="l" name="66" href="#66">66</a>  <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=log">log</a>(<span class="s">'Express server listening at: <a href="http://localhost:%d/">http://localhost:%d/</a>'</span>, <a class="d" href="#app">app</a>.<a href="/source/s?defs=get">get</a>(<span class="s">'port'</span>));
<a class="l" name="67" href="#67">67</a>});
<a class="l" name="68" href="#68">68</a>