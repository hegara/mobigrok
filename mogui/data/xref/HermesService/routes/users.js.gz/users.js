<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["Source",5],["User",4]]],["Function","xf",[["exports.create",22],["exports.del",73],["exports.edit",58],["exports.enlist",118],["exports.follow",86],["exports.list",10],["exports.show",35],["exports.unfollow",102],["exports.unlist",134]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">// <a href="/source/s?path=users.js">users.js</a></span>
<a class="l" name="2" href="#2">2</a><span class="c">// Routes to CRUD users.</span>
<a class="l" name="3" href="#3">3</a>
<a class="l" name="4" href="#4">4</a><b>var</b> <a class="xv" name="User"/><a href="/source/s?refs=User" class="xv">User</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'../<a href="/source/s?path=/models/">models</a>/<a href="/source/s?path=/models/user">user</a>'</span>);
<a class="l" name="5" href="#5">5</a><b>var</b> <a class="xv" name="Source"/><a href="/source/s?refs=Source" class="xv">Source</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'../<a href="/source/s?path=/models/">models</a>/<a href="/source/s?path=/models/source">source</a>'</span>);
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a><span class="c">/**
<a class="l" name="8" href="#8">8</a> * GET /users
<a class="l" name="9" href="#9">9</a> */</span>
<a class="hl" name="10" href="#10">10</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=list">list</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="l" name="11" href="#11">11</a>    <a class="d" href="#User">User</a>.<a href="/source/s?defs=getAll">getAll</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=users">users</a>) {
<a class="l" name="12" href="#12">12</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="13" href="#13">13</a>        <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=render">render</a>(<span class="s">'users'</span>, {
<a class="l" name="14" href="#14">14</a>            <a href="/source/s?defs=users">users</a>: <a href="/source/s?defs=users">users</a>
<a class="l" name="15" href="#15">15</a>        });
<a class="l" name="16" href="#16">16</a>    });
<a class="l" name="17" href="#17">17</a>};
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a><span class="c">/**
<a class="hl" name="20" href="#20">20</a> * POST /users
<a class="l" name="21" href="#21">21</a> */</span>
<a class="l" name="22" href="#22">22</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=create">create</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="l" name="23" href="#23">23</a>    <a class="d" href="#User">User</a>.<a href="/source/s?defs=create">create</a>({
<a class="l" name="24" href="#24">24</a>        <a href="/source/s?defs=name">name</a>: <a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>[<span class="s">'name'</span>],
<a class="l" name="25" href="#25">25</a>        <a href="/source/s?defs=email">email</a>: <a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>[<span class="s">'email'</span>]
<a class="l" name="26" href="#26">26</a>    }, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="l" name="27" href="#27">27</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="28" href="#28">28</a>        <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=redirect">redirect</a>(<span class="s">'/users/'</span> + <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=id">id</a>);
<a class="l" name="29" href="#29">29</a>    });
<a class="hl" name="30" href="#30">30</a>};
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a><span class="c">/**
<a class="l" name="33" href="#33">33</a> * GET /users/:id
<a class="l" name="34" href="#34">34</a> */</span>
<a class="l" name="35" href="#35">35</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=show">show</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="l" name="36" href="#36">36</a>    <a class="d" href="#User">User</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=params">params</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="l" name="37" href="#37">37</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="38" href="#38">38</a>        <span class="c">// TODO also fetch and show followers? (not just follow*ing*)</span>
<a class="l" name="39" href="#39">39</a>        <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=getFollowingAndOthers">getFollowingAndOthers</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=following">following</a>, <a href="/source/s?defs=others">others</a>) {
<a class="hl" name="40" href="#40">40</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="41" href="#41">41</a>            <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=getEnlistingAndOthers">getEnlistingAndOthers</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=enlisting">enlisting</a>, <a href="/source/s?defs=sources">sources</a>) {
<a class="l" name="42" href="#42">42</a>                <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="43" href="#43">43</a>                <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=render">render</a>(<span class="s">'user'</span>, {
<a class="l" name="44" href="#44">44</a>                    <a href="/source/s?defs=user">user</a>: <a href="/source/s?defs=user">user</a>,
<a class="l" name="45" href="#45">45</a>                    <a href="/source/s?defs=following">following</a>: <a href="/source/s?defs=following">following</a>,
<a class="l" name="46" href="#46">46</a>                    <a href="/source/s?defs=others">others</a>: <a href="/source/s?defs=others">others</a>,
<a class="l" name="47" href="#47">47</a>                    <a href="/source/s?defs=enlisting">enlisting</a>: <a href="/source/s?defs=enlisting">enlisting</a>,
<a class="l" name="48" href="#48">48</a>                    <a href="/source/s?defs=sources">sources</a>: <a href="/source/s?defs=sources">sources</a>
<a class="l" name="49" href="#49">49</a>                });
<a class="hl" name="50" href="#50">50</a>            });
<a class="l" name="51" href="#51">51</a>        });
<a class="l" name="52" href="#52">52</a>    });
<a class="l" name="53" href="#53">53</a>};
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a><span class="c">/**
<a class="l" name="56" href="#56">56</a> * POST /users/:id
<a class="l" name="57" href="#57">57</a> */</span>
<a class="l" name="58" href="#58">58</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=edit">edit</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="l" name="59" href="#59">59</a>    <a class="d" href="#User">User</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=params">params</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="hl" name="60" href="#60">60</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="61" href="#61">61</a>        <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=name">name</a> = <a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>[<span class="s">'name'</span>];
<a class="l" name="62" href="#62">62</a>        <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=email">email</a> = <a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>[<span class="s">'email'</span>];
<a class="l" name="63" href="#63">63</a>        <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=save">save</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="64" href="#64">64</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="65" href="#65">65</a>            <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=redirect">redirect</a>(<span class="s">'/users/'</span> + <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=id">id</a>);
<a class="l" name="66" href="#66">66</a>        });
<a class="l" name="67" href="#67">67</a>    });
<a class="l" name="68" href="#68">68</a>};
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a><span class="c">/**
<a class="l" name="71" href="#71">71</a> * DELETE /users/:id
<a class="l" name="72" href="#72">72</a> */</span>
<a class="l" name="73" href="#73">73</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=del">del</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="l" name="74" href="#74">74</a>    <a class="d" href="#User">User</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=params">params</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="l" name="75" href="#75">75</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="76" href="#76">76</a>        <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=del">del</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="77" href="#77">77</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="78" href="#78">78</a>            <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=redirect">redirect</a>(<span class="s">'/users'</span>);
<a class="l" name="79" href="#79">79</a>        });
<a class="hl" name="80" href="#80">80</a>    });
<a class="l" name="81" href="#81">81</a>};
<a class="l" name="82" href="#82">82</a>
<a class="l" name="83" href="#83">83</a><span class="c">/**
<a class="l" name="84" href="#84">84</a> * POST /users/:<a href="/source/s?path=id/">id</a>/<a href="/source/s?path=id/follow">follow</a>
<a class="l" name="85" href="#85">85</a> */</span>
<a class="l" name="86" href="#86">86</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=follow">follow</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="l" name="87" href="#87">87</a>    <a class="d" href="#User">User</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=params">params</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="l" name="88" href="#88">88</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="89" href="#89">89</a>        <a class="d" href="#User">User</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>.<a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=other">other</a>) {
<a class="hl" name="90" href="#90">90</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="91" href="#91">91</a>            <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=follow">follow</a>(<a href="/source/s?defs=other">other</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="92" href="#92">92</a>                <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="93" href="#93">93</a>                <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=redirect">redirect</a>(<span class="s">'/users/'</span> + <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=id">id</a>);
<a class="l" name="94" href="#94">94</a>            });
<a class="l" name="95" href="#95">95</a>        });
<a class="l" name="96" href="#96">96</a>    });
<a class="l" name="97" href="#97">97</a>};
<a class="l" name="98" href="#98">98</a>
<a class="l" name="99" href="#99">99</a><span class="c">/**
<a class="hl" name="100" href="#100">100</a> * POST /users/:<a href="/source/s?path=id/">id</a>/<a href="/source/s?path=id/unfollow">unfollow</a>
<a class="l" name="101" href="#101">101</a> */</span>
<a class="l" name="102" href="#102">102</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=unfollow">unfollow</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="l" name="103" href="#103">103</a>    <a class="d" href="#User">User</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=params">params</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="l" name="104" href="#104">104</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="105" href="#105">105</a>        <a class="d" href="#User">User</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>.<a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=other">other</a>) {
<a class="l" name="106" href="#106">106</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="107" href="#107">107</a>            <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=unfollow">unfollow</a>(<a href="/source/s?defs=other">other</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="108" href="#108">108</a>                <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="109" href="#109">109</a>                <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=redirect">redirect</a>(<span class="s">'/users/'</span> + <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=id">id</a>);
<a class="hl" name="110" href="#110">110</a>            });
<a class="l" name="111" href="#111">111</a>        });
<a class="l" name="112" href="#112">112</a>    });
<a class="l" name="113" href="#113">113</a>};
<a class="l" name="114" href="#114">114</a>
<a class="l" name="115" href="#115">115</a><span class="c">/**
<a class="l" name="116" href="#116">116</a> * POST /users/:<a href="/source/s?path=id/">id</a>/<a href="/source/s?path=id/enlist">enlist</a>
<a class="l" name="117" href="#117">117</a> */</span>
<a class="l" name="118" href="#118">118</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=enlist">enlist</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="l" name="119" href="#119">119</a>    <a class="d" href="#User">User</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=params">params</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="hl" name="120" href="#120">120</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="121" href="#121">121</a>        <a class="d" href="#Source">Source</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>.<a href="/source/s?defs=source">source</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=source">source</a>) {
<a class="l" name="122" href="#122">122</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="123" href="#123">123</a>            <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=enlist">enlist</a>(<a href="/source/s?defs=source">source</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="124" href="#124">124</a>                <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="125" href="#125">125</a>                <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=redirect">redirect</a>(<span class="s">'/users/'</span> + <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=id">id</a>);
<a class="l" name="126" href="#126">126</a>            });
<a class="l" name="127" href="#127">127</a>        });
<a class="l" name="128" href="#128">128</a>    });
<a class="l" name="129" href="#129">129</a>};
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a><span class="c">/**
<a class="l" name="132" href="#132">132</a> * POST /users/:<a href="/source/s?path=id/">id</a>/<a href="/source/s?path=id/unlist">unlist</a>
<a class="l" name="133" href="#133">133</a> */</span>
<a class="l" name="134" href="#134">134</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=unlist">unlist</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="l" name="135" href="#135">135</a>    <a class="d" href="#User">User</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=params">params</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=user">user</a>) {
<a class="l" name="136" href="#136">136</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="137" href="#137">137</a>        <a class="d" href="#Source">Source</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>.<a href="/source/s?defs=source">source</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=source">source</a>) {
<a class="l" name="138" href="#138">138</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="139" href="#139">139</a>            <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=unlist">unlist</a>(<a href="/source/s?defs=source">source</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="hl" name="140" href="#140">140</a>                <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="141" href="#141">141</a>                <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=redirect">redirect</a>(<span class="s">'/users/'</span> + <a href="/source/s?defs=user">user</a>.<a href="/source/s?defs=id">id</a>);
<a class="l" name="142" href="#142">142</a>            });
<a class="l" name="143" href="#143">143</a>        });
<a class="l" name="144" href="#144">144</a>    });
<a class="l" name="145" href="#145">145</a>};
<a class="l" name="146" href="#146">146</a>