<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Function","xf",[["exports.index",6]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>
<a class="l" name="2" href="#2">2</a><span class="c">/*
<a class="l" name="3" href="#3">3</a> * GET home page.
<a class="l" name="4" href="#4">4</a> */</span>
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=index">index</a> = <b>function</b>(<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>){
<a class="l" name="7" href="#7">7</a>  <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=render">render</a>(<span class="s">'index'</span>);
<a class="l" name="8" href="#8">8</a>};
<a class="l" name="9" href="#9">9</a>