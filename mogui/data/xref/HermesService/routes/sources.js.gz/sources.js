<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["Source",4]]],["Function","xf",[["exports.create",22],["exports.del",69],["exports.edit",53],["exports.list",9],["exports.show",36]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">// <a href="/source/s?path=sources.js">sources.js</a></span>
<a class="l" name="2" href="#2">2</a><span class="c">// Routes to CRUD sources.</span>
<a class="l" name="3" href="#3">3</a>
<a class="l" name="4" href="#4">4</a><b>var</b> <a class="xv" name="Source"/><a href="/source/s?refs=Source" class="xv">Source</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'../<a href="/source/s?path=/models/">models</a>/<a href="/source/s?path=/models/source">source</a>'</span>);
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a><span class="c">/**
<a class="l" name="7" href="#7">7</a> * GET /sources
<a class="l" name="8" href="#8">8</a> */</span>
<a class="l" name="9" href="#9">9</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=list">list</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="hl" name="10" href="#10">10</a>    <a class="d" href="#Source">Source</a>.<a href="/source/s?defs=getAll">getAll</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=sources">sources</a>) {
<a class="l" name="11" href="#11">11</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="12" href="#12">12</a>        <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=render">render</a>(<span class="s">'sources'</span>, {
<a class="l" name="13" href="#13">13</a>            <a href="/source/s?defs=sources">sources</a>: <a href="/source/s?defs=sources">sources</a>,
<a class="l" name="14" href="#14">14</a>            <a href="/source/s?defs=alltypes">alltypes</a>: [<span class="s">'git'</span>,<span class="s">'mercurial'</span>,<span class="s">'svn'</span>]
<a class="l" name="15" href="#15">15</a>        });
<a class="l" name="16" href="#16">16</a>    });
<a class="l" name="17" href="#17">17</a>};
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a><span class="c">/**
<a class="hl" name="20" href="#20">20</a> * POST /sources
<a class="l" name="21" href="#21">21</a> */</span>
<a class="l" name="22" href="#22">22</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=create">create</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="l" name="23" href="#23">23</a>    <a class="d" href="#Source">Source</a>.<a href="/source/s?defs=create">create</a>({
<a class="l" name="24" href="#24">24</a>        <a href="/source/s?defs=name">name</a>: <a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>[<span class="s">'name'</span>],
<a class="l" name="25" href="#25">25</a>        <a href="/source/s?defs=type">type</a>: <a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>[<span class="s">'type'</span>],
<a class="l" name="26" href="#26">26</a>        <a href="/source/s?defs=url">url</a>: <a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>[<span class="s">'url'</span>]
<a class="l" name="27" href="#27">27</a>    }, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=source">source</a>) {
<a class="l" name="28" href="#28">28</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="29" href="#29">29</a>        <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=redirect">redirect</a>(<span class="s">'/sources/'</span> + <a href="/source/s?defs=source">source</a>.<a href="/source/s?defs=id">id</a>);
<a class="hl" name="30" href="#30">30</a>    });
<a class="l" name="31" href="#31">31</a>};
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a><span class="c">/**
<a class="l" name="34" href="#34">34</a> * GET /sources/:id
<a class="l" name="35" href="#35">35</a> */</span>
<a class="l" name="36" href="#36">36</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=show">show</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="l" name="37" href="#37">37</a>    <a class="d" href="#Source">Source</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=params">params</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=source">source</a>) {
<a class="l" name="38" href="#38">38</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="39" href="#39">39</a>        <span class="c">// TODO also fetch and show followers? (not just follow*ing*)</span>
<a class="hl" name="40" href="#40">40</a>        <a href="/source/s?defs=source">source</a>.<a href="/source/s?defs=getEnlisters">getEnlisters</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=enlisters">enlisters</a>){
<a class="l" name="41" href="#41">41</a>            <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=render">render</a>(<span class="s">'source'</span>, {
<a class="l" name="42" href="#42">42</a>                <a href="/source/s?defs=source">source</a>: <a href="/source/s?defs=source">source</a>,
<a class="l" name="43" href="#43">43</a>                <a href="/source/s?defs=enlisters">enlisters</a>: <a href="/source/s?defs=enlisters">enlisters</a>,
<a class="l" name="44" href="#44">44</a>                <a href="/source/s?defs=alltypes">alltypes</a>: [<span class="s">'git'</span>,<span class="s">'mercurial'</span>,<span class="s">'svn'</span>]
<a class="l" name="45" href="#45">45</a>            });
<a class="l" name="46" href="#46">46</a>        });
<a class="l" name="47" href="#47">47</a>    });
<a class="l" name="48" href="#48">48</a>};
<a class="l" name="49" href="#49">49</a>
<a class="hl" name="50" href="#50">50</a><span class="c">/**
<a class="l" name="51" href="#51">51</a> * POST /sources/:id
<a class="l" name="52" href="#52">52</a> */</span>
<a class="l" name="53" href="#53">53</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=edit">edit</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="l" name="54" href="#54">54</a>    <a class="d" href="#Source">Source</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=params">params</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=source">source</a>) {
<a class="l" name="55" href="#55">55</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="56" href="#56">56</a>        <a href="/source/s?defs=source">source</a>.<a href="/source/s?defs=name">name</a> = <a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>[<span class="s">'name'</span>];
<a class="l" name="57" href="#57">57</a>        <a href="/source/s?defs=source">source</a>.<a href="/source/s?defs=type">type</a> = <a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>[<span class="s">'type'</span>];
<a class="l" name="58" href="#58">58</a>        <a href="/source/s?defs=source">source</a>.<a href="/source/s?defs=url">url</a> = <a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=body">body</a>[<span class="s">'url'</span>];
<a class="l" name="59" href="#59">59</a>        <a href="/source/s?defs=source">source</a>.<a href="/source/s?defs=save">save</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="hl" name="60" href="#60">60</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="61" href="#61">61</a>            <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=redirect">redirect</a>(<span class="s">'/sources/'</span> + <a href="/source/s?defs=source">source</a>.<a href="/source/s?defs=id">id</a>);
<a class="l" name="62" href="#62">62</a>        });
<a class="l" name="63" href="#63">63</a>    });
<a class="l" name="64" href="#64">64</a>};
<a class="l" name="65" href="#65">65</a>
<a class="l" name="66" href="#66">66</a><span class="c">/**
<a class="l" name="67" href="#67">67</a> * DELETE /sources/:id
<a class="l" name="68" href="#68">68</a> */</span>
<a class="l" name="69" href="#69">69</a><a href="/source/s?defs=exports">exports</a>.<a href="/source/s?defs=del">del</a> = <b>function</b> (<a href="/source/s?defs=req">req</a>, <a href="/source/s?defs=res">res</a>, <a href="/source/s?defs=next">next</a>) {
<a class="hl" name="70" href="#70">70</a>    <a class="d" href="#Source">Source</a>.<a href="/source/s?defs=get">get</a>(<a href="/source/s?defs=req">req</a>.<a href="/source/s?defs=params">params</a>.<a href="/source/s?defs=id">id</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=source">source</a>) {
<a class="l" name="71" href="#71">71</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="72" href="#72">72</a>        <a href="/source/s?defs=source">source</a>.<a href="/source/s?defs=del">del</a>(<b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="73" href="#73">73</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <b>return</b> <a href="/source/s?defs=next">next</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="74" href="#74">74</a>            <a href="/source/s?defs=res">res</a>.<a href="/source/s?defs=redirect">redirect</a>(<span class="s">'/sources'</span>);
<a class="l" name="75" href="#75">75</a>        });
<a class="l" name="76" href="#76">76</a>    });
<a class="l" name="77" href="#77">77</a>};
<a class="l" name="78" href="#78">78</a>