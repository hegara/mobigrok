<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["Indexer",12]]],["Package","xp",[["org.hermes.util",1]]],["Method","xmt",[["Indexer",22],["delete",46],["execHelper",30],["gitClone",70],["main",83],["opengrokIndex",76],["prepare",55]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org">org</a>.<a href="/source/s?defs=hermes">hermes</a>.<a href="/source/s?defs=util">util</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><b>import</b> <a href="/source/s?defs=java">java</a>.<a href="/source/s?defs=io">io</a>.<a href="/source/s?defs=File">File</a>;
<a class="l" name="4" href="#4">4</a><b>import</b> <a href="/source/s?defs=java">java</a>.<a href="/source/s?defs=io">io</a>.<a href="/source/s?defs=FileNotFoundException">FileNotFoundException</a>;
<a class="l" name="5" href="#5">5</a><b>import</b> <a href="/source/s?defs=java">java</a>.<a href="/source/s?defs=io">io</a>.<a href="/source/s?defs=IOException">IOException</a>;
<a class="l" name="6" href="#6">6</a><b>import</b> <a href="/source/s?defs=java">java</a>.<a href="/source/s?defs=util">util</a>.<a href="/source/s?defs=logging">logging</a>.<a href="/source/s?defs=Level">Level</a>;
<a class="l" name="7" href="#7">7</a><b>import</b> <a href="/source/s?defs=java">java</a>.<a href="/source/s?defs=util">util</a>.<a href="/source/s?defs=logging">logging</a>.<a href="/source/s?defs=Logger">Logger</a>;
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a><b>import</b> <a href="/source/s?defs=org">org</a>.<a href="/source/s?defs=hermes">hermes</a>.<a href="/source/s?defs=configuration">configuration</a>.<a href="/source/s?defs=Env">Env</a>;
<a class="hl" name="10" href="#10">10</a><b>import</b> <a href="/source/s?defs=org">org</a>.<a href="/source/s?defs=opensolaris">opensolaris</a>.<a href="/source/s?defs=opengrok">opengrok</a>.<a href="/source/s?defs=util">util</a>.<a href="/source/s?defs=Executor">Executor</a>;
<a class="l" name="11" href="#11">11</a>
<a class="l" name="12" href="#12">12</a><b>public</b> <b>class</b> <a class="xc" name="Indexer"/><a href="/source/s?refs=Indexer" class="xc">Indexer</a> {
<a class="l" name="13" href="#13">13</a>	<b>private</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Logger">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log" class="xfld">log</a> = <a href="/source/s?defs=Logger">Logger</a>.<a href="/source/s?defs=getLogger">getLogger</a>(<a href="/source/s?defs=Indexer">Indexer</a>.<b>class</b>
<a class="l" name="14" href="#14">14</a>			.<a href="/source/s?defs=getSimpleName">getSimpleName</a>());
<a class="l" name="15" href="#15">15</a>
<a class="l" name="16" href="#16">16</a>	<b>private</b> <a href="/source/s?defs=String">String</a> <a class="xfld" name="_url"/><a href="/source/s?refs=_url" class="xfld">_url</a>;
<a class="l" name="17" href="#17">17</a>	<b>private</b> <a href="/source/s?defs=File">File</a> <a class="xfld" name="_targetRoot"/><a href="/source/s?refs=_targetRoot" class="xfld">_targetRoot</a>;
<a class="l" name="18" href="#18">18</a>	<b>private</b> <a href="/source/s?defs=File">File</a> <a class="xfld" name="_sourceCodeDir"/><a href="/source/s?refs=_sourceCodeDir" class="xfld">_sourceCodeDir</a>;
<a class="l" name="19" href="#19">19</a>	<b>private</b> <a href="/source/s?defs=File">File</a> <a class="xfld" name="_indexDataDir"/><a href="/source/s?refs=_indexDataDir" class="xfld">_indexDataDir</a>;
<a class="hl" name="20" href="#20">20</a>	<b>private</b> <a href="/source/s?defs=File">File</a> <a class="xfld" name="_configFile"/><a href="/source/s?refs=_configFile" class="xfld">_configFile</a>;
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a>	<b>public</b> <a class="xmt" name="Indexer"/><a href="/source/s?refs=Indexer" class="xmt">Indexer</a>(<a href="/source/s?defs=String">String</a> <a class="xa" name="url"/><a href="/source/s?refs=url" class="xa">url</a>, <a href="/source/s?defs=String">String</a> <a class="xa" name="targetPath"/><a href="/source/s?refs=targetPath" class="xa">targetPath</a>) {
<a class="l" name="23" href="#23">23</a>		<a class="d" href="#_url">_url</a> = <a class="d" href="#url">url</a>;
<a class="l" name="24" href="#24">24</a>		<a class="d" href="#_targetRoot">_targetRoot</a> = <b>new</b> <a href="/source/s?defs=File">File</a>(<a class="d" href="#targetPath">targetPath</a>);
<a class="l" name="25" href="#25">25</a>		<a class="d" href="#_sourceCodeDir">_sourceCodeDir</a> = <b>new</b> <a href="/source/s?defs=File">File</a>(<a class="d" href="#_targetRoot">_targetRoot</a>, <span class="s">"src"</span>);
<a class="l" name="26" href="#26">26</a>		<a class="d" href="#_indexDataDir">_indexDataDir</a> = <b>new</b> <a href="/source/s?defs=File">File</a>(<a class="d" href="#_targetRoot">_targetRoot</a>, <span class="s">"data"</span>);
<a class="l" name="27" href="#27">27</a>		<a class="d" href="#_configFile">_configFile</a> = <b>new</b> <a href="/source/s?defs=File">File</a>(<a class="d" href="#_targetRoot">_targetRoot</a>, <span class="s">"<a href="/source/s?path=configuration.xml">configuration.xml</a>"</span>);
<a class="l" name="28" href="#28">28</a>	}
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a>	<b>private</b> <b>static</b> <b>void</b> <a class="xmt" name="execHelper"/><a href="/source/s?refs=execHelper" class="xmt">execHelper</a>(<a href="/source/s?defs=String">String</a>[] <a class="xa" name="cmdlist"/><a href="/source/s?refs=cmdlist" class="xa">cmdlist</a>) {
<a class="l" name="31" href="#31">31</a>		<a href="/source/s?defs=Executor">Executor</a> <a href="/source/s?defs=executor">executor</a> = <b>new</b> <a href="/source/s?defs=Executor">Executor</a>(<a class="d" href="#cmdlist">cmdlist</a>);
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>		<b>int</b> <a href="/source/s?defs=ret">ret</a> = <a href="/source/s?defs=executor">executor</a>.<a href="/source/s?defs=exec">exec</a>(<b>false</b>);
<a class="l" name="34" href="#34">34</a>		<a href="/source/s?defs=String">String</a> <a href="/source/s?defs=output">output</a> = <a href="/source/s?defs=executor">executor</a>.<a href="/source/s?defs=getOutputString">getOutputString</a>();
<a class="l" name="35" href="#35">35</a>		<b>if</b> (<a href="/source/s?defs=output">output</a>.<a href="/source/s?defs=length">length</a>() == <span class="n">0</span>) {
<a class="l" name="36" href="#36">36</a>			<a href="/source/s?defs=output">output</a> = <a href="/source/s?defs=executor">executor</a>.<a href="/source/s?defs=getErrorString">getErrorString</a>();
<a class="l" name="37" href="#37">37</a>		}
<a class="l" name="38" href="#38">38</a>		<a href="/source/s?defs=Level">Level</a> <a href="/source/s?defs=logLevel">logLevel</a> = <a href="/source/s?defs=Level">Level</a>.<a href="/source/s?defs=INFO">INFO</a>;
<a class="l" name="39" href="#39">39</a>		<b>if</b> (<a href="/source/s?defs=ret">ret</a> != <span class="n">0</span>) {
<a class="hl" name="40" href="#40">40</a>			<a href="/source/s?defs=logLevel">logLevel</a> = <a href="/source/s?defs=Level">Level</a>.<a href="/source/s?defs=WARNING">WARNING</a>;
<a class="l" name="41" href="#41">41</a>		}
<a class="l" name="42" href="#42">42</a>		<a class="d" href="#log">log</a>.<a class="d" href="#log">log</a>(<a href="/source/s?defs=logLevel">logLevel</a>, <span class="s">"{0}..."</span>, <a href="/source/s?defs=output">output</a>);
<a class="l" name="43" href="#43">43</a>		<b>return</b>;
<a class="l" name="44" href="#44">44</a>	}
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a>	<b>private</b> <b>static</b> <b>void</b> <a class="xmt" name="delete"/><a href="/source/s?refs=delete" class="xmt">delete</a>(<a href="/source/s?defs=File">File</a> f) <b>throws</b> <a href="/source/s?defs=IOException">IOException</a> {
<a class="l" name="47" href="#47">47</a>		<b>if</b> (f.<a href="/source/s?defs=isDirectory">isDirectory</a>()) {
<a class="l" name="48" href="#48">48</a>			<b>for</b> (<a href="/source/s?defs=File">File</a> c : f.<a href="/source/s?defs=listFiles">listFiles</a>())
<a class="l" name="49" href="#49">49</a>				<a class="d" href="#delete">delete</a>(c);
<a class="hl" name="50" href="#50">50</a>		}
<a class="l" name="51" href="#51">51</a>		<b>if</b> (!f.<a class="d" href="#delete">delete</a>())
<a class="l" name="52" href="#52">52</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=FileNotFoundException">FileNotFoundException</a>(<span class="s">"Failed to delete file: "</span> + f);
<a class="l" name="53" href="#53">53</a>	}
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>	<b>public</b> <b>void</b> <a class="xmt" name="prepare"/><a href="/source/s?refs=prepare" class="xmt">prepare</a>() {
<a class="l" name="56" href="#56">56</a>		<b>if</b> (<a class="d" href="#_targetRoot">_targetRoot</a>.<a href="/source/s?defs=exists">exists</a>()) {
<a class="l" name="57" href="#57">57</a>			<b>try</b> {
<a class="l" name="58" href="#58">58</a>				<a class="d" href="#delete">delete</a>(<a class="d" href="#_targetRoot">_targetRoot</a>);
<a class="l" name="59" href="#59">59</a>			} <b>catch</b> (<a href="/source/s?defs=Throwable">Throwable</a> e) {
<a class="hl" name="60" href="#60">60</a>				<a class="d" href="#log">log</a>.<a class="d" href="#log">log</a>(<a href="/source/s?defs=Level">Level</a>.<a href="/source/s?defs=SEVERE">SEVERE</a>,
<a class="l" name="61" href="#61">61</a>						<span class="s">"Target folder cannot be accessed while preparing: {0}\n{1}"</span>,
<a class="l" name="62" href="#62">62</a>						<b>new</b> <a href="/source/s?defs=String">String</a>[] { <a class="d" href="#_targetRoot">_targetRoot</a>.<a href="/source/s?defs=getPath">getPath</a>(), e.<a href="/source/s?defs=getMessage">getMessage</a>() });
<a class="l" name="63" href="#63">63</a>				<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException">RuntimeException</a>(e);
<a class="l" name="64" href="#64">64</a>			}
<a class="l" name="65" href="#65">65</a>		}
<a class="l" name="66" href="#66">66</a>		<a class="d" href="#_targetRoot">_targetRoot</a>.<a href="/source/s?defs=mkdirs">mkdirs</a>();
<a class="l" name="67" href="#67">67</a>		<a class="d" href="#log">log</a>.<a class="d" href="#log">log</a>(<a href="/source/s?defs=Level">Level</a>.<a href="/source/s?defs=INFO">INFO</a>, <span class="s">"Directory prepared"</span>);
<a class="l" name="68" href="#68">68</a>	}
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a>	<b>public</b> <b>void</b> <a class="xmt" name="gitClone"/><a href="/source/s?refs=gitClone" class="xmt">gitClone</a>() {
<a class="l" name="71" href="#71">71</a>		<a class="d" href="#execHelper">execHelper</a>(<b>new</b> <a href="/source/s?defs=String">String</a>[] { <a href="/source/s?defs=Env">Env</a>.<a href="/source/s?defs=getGit">getGit</a>(), <span class="s">"clone"</span>, <span class="s">"--progress"</span>,
<a class="l" name="72" href="#72">72</a>				<span class="s">"--recursive"</span>, <span class="s">"--depth"</span>, <span class="s">"1"</span>, <a class="d" href="#_url">_url</a>, <a class="d" href="#_sourceCodeDir">_sourceCodeDir</a>.<a href="/source/s?defs=getPath">getPath</a>() });
<a class="l" name="73" href="#73">73</a>		<a class="d" href="#log">log</a>.<a class="d" href="#log">log</a>(<a href="/source/s?defs=Level">Level</a>.<a href="/source/s?defs=INFO">INFO</a>, <span class="s">"Source code downloaded via git"</span>);
<a class="l" name="74" href="#74">74</a>	}
<a class="l" name="75" href="#75">75</a>
<a class="l" name="76" href="#76">76</a>	<b>public</b> <b>void</b> <a class="xmt" name="opengrokIndex"/><a href="/source/s?refs=opengrokIndex" class="xmt">opengrokIndex</a>() {
<a class="l" name="77" href="#77">77</a>		<a class="d" href="#execHelper">execHelper</a>(<b>new</b> <a href="/source/s?defs=String">String</a>[] { <a href="/source/s?defs=Env">Env</a>.<a href="/source/s?defs=getJava">getJava</a>(), <span class="s">"-jar"</span>, <a href="/source/s?defs=Env">Env</a>.<a href="/source/s?defs=getOpengrok">getOpengrok</a>(),
<a class="l" name="78" href="#78">78</a>				<span class="s">"-c"</span>, <a href="/source/s?defs=Env">Env</a>.<a href="/source/s?defs=getCtags">getCtags</a>(), <span class="s">"-d"</span>, <a class="d" href="#_indexDataDir">_indexDataDir</a>.<a href="/source/s?defs=getPath">getPath</a>(), <span class="s">"-s"</span>,
<a class="l" name="79" href="#79">79</a>				<a class="d" href="#_sourceCodeDir">_sourceCodeDir</a>.<a href="/source/s?defs=getPath">getPath</a>(), <span class="s">"-W"</span>, <a class="d" href="#_configFile">_configFile</a>.<a href="/source/s?defs=getPath">getPath</a>(), <span class="s">"-v"</span> });
<a class="hl" name="80" href="#80">80</a>		<a class="d" href="#log">log</a>.<a class="d" href="#log">log</a>(<a href="/source/s?defs=Level">Level</a>.<a href="/source/s?defs=INFO">INFO</a>, <span class="s">"Index done via OpenGrok"</span>);
<a class="l" name="81" href="#81">81</a>	}
<a class="l" name="82" href="#82">82</a>
<a class="l" name="83" href="#83">83</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="main"/><a href="/source/s?refs=main" class="xmt">main</a>(<a href="/source/s?defs=String">String</a>[] <a class="xa" name="args"/><a href="/source/s?refs=args" class="xa">args</a>) {
<a class="l" name="84" href="#84">84</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=setLevel">setLevel</a>(<a href="/source/s?defs=Level">Level</a>.<a href="/source/s?defs=ALL">ALL</a>);
<a class="l" name="85" href="#85">85</a>		<b>if</b> (<a href="/source/s?defs=Env">Env</a>.<a href="/source/s?defs=validateExuberantCtags">validateExuberantCtags</a>() &amp;&amp; <a href="/source/s?defs=Env">Env</a>.<a href="/source/s?defs=validateOpenGrok">validateOpenGrok</a>()
<a class="l" name="86" href="#86">86</a>				&amp;&amp; <a href="/source/s?defs=Env">Env</a>.<a href="/source/s?defs=validateGit">validateGit</a>()) {
<a class="l" name="87" href="#87">87</a>			<a href="/source/s?defs=Indexer">Indexer</a> <a href="/source/s?defs=indexer">indexer</a> = <b>new</b> <a href="/source/s?defs=Indexer">Indexer</a>(<a class="d" href="#args">args</a>[<span class="n">0</span>], <a class="d" href="#args">args</a>[<span class="n">1</span>]);
<a class="l" name="88" href="#88">88</a>			<a href="/source/s?defs=indexer">indexer</a>.<a class="d" href="#prepare">prepare</a>();
<a class="l" name="89" href="#89">89</a>			<a href="/source/s?defs=indexer">indexer</a>.<a class="d" href="#gitClone">gitClone</a>();
<a class="hl" name="90" href="#90">90</a>			<a href="/source/s?defs=indexer">indexer</a>.<a class="d" href="#opengrokIndex">opengrokIndex</a>();
<a class="l" name="91" href="#91">91</a>			<a href="/source/s?defs=System">System</a>.<a href="/source/s?defs=out">out</a>.<a href="/source/s?defs=println">println</a>(<span class="s">"Done!"</span>);
<a class="l" name="92" href="#92">92</a>		}
<a class="l" name="93" href="#93">93</a>	}
<a class="l" name="94" href="#94">94</a>
<a class="l" name="95" href="#95">95</a>}
<a class="l" name="96" href="#96">96</a>