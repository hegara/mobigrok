<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["Env",8]]],["Package","xp",[["org.hermes.configuration",1]]],["Method","xmt",[["getCtags",12],["getGit",24],["getJava",20],["getOpengrok",16],["validateCommandHelper",28],["validateExuberantCtags",54],["validateGit",44],["validateOpenGrok",49]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org">org</a>.<a href="/source/s?defs=hermes">hermes</a>.<a href="/source/s?defs=configuration">configuration</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><b>import</b> <a href="/source/s?defs=java">java</a>.<a href="/source/s?defs=util">util</a>.<a href="/source/s?defs=logging">logging</a>.<a href="/source/s?defs=Level">Level</a>;
<a class="l" name="4" href="#4">4</a><b>import</b> <a href="/source/s?defs=java">java</a>.<a href="/source/s?defs=util">util</a>.<a href="/source/s?defs=logging">logging</a>.<a href="/source/s?defs=Logger">Logger</a>;
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a><b>import</b> <a href="/source/s?defs=org">org</a>.<a href="/source/s?defs=opensolaris">opensolaris</a>.<a href="/source/s?defs=opengrok">opengrok</a>.<a href="/source/s?defs=util">util</a>.<a href="/source/s?defs=Executor">Executor</a>;
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a><b>public</b> <b>class</b> <a class="xc" name="Env"/><a href="/source/s?refs=Env" class="xc">Env</a> {
<a class="l" name="9" href="#9">9</a>	<b>private</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Logger">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log" class="xfld">log</a> = <a href="/source/s?defs=Logger">Logger</a>.<a href="/source/s?defs=getLogger">getLogger</a>(<a class="d" href="#Env">Env</a>.<b>class</b>
<a class="hl" name="10" href="#10">10</a>			.<a href="/source/s?defs=getSimpleName">getSimpleName</a>());
<a class="l" name="11" href="#11">11</a>
<a class="l" name="12" href="#12">12</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String">String</a> <a class="xmt" name="getCtags"/><a href="/source/s?refs=getCtags" class="xmt">getCtags</a>() {
<a class="l" name="13" href="#13">13</a>		<b>return</b> <span class="s">"C:\\tools\\ctags58\\ctags.exe"</span>;
<a class="l" name="14" href="#14">14</a>	}
<a class="l" name="15" href="#15">15</a>
<a class="l" name="16" href="#16">16</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String">String</a> <a class="xmt" name="getOpengrok"/><a href="/source/s?refs=getOpengrok" class="xmt">getOpengrok</a>() {
<a class="l" name="17" href="#17">17</a>		<b>return</b> <span class="s">".\\opengrok.jar"</span>;
<a class="l" name="18" href="#18">18</a>	}
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String">String</a> <a class="xmt" name="getJava"/><a href="/source/s?refs=getJava" class="xmt">getJava</a>() {
<a class="l" name="21" href="#21">21</a>		<b>return</b> <span class="s">"java"</span>;
<a class="l" name="22" href="#22">22</a>	}
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String">String</a> <a class="xmt" name="getGit"/><a href="/source/s?refs=getGit" class="xmt">getGit</a>() {
<a class="l" name="25" href="#25">25</a>		<b>return</b> <span class="s">"git"</span>;
<a class="l" name="26" href="#26">26</a>	}
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a>	<b>private</b> <b>static</b> <b>boolean</b> <a class="xmt" name="validateCommandHelper"/><a href="/source/s?refs=validateCommandHelper" class="xmt">validateCommandHelper</a>(<a href="/source/s?defs=Executor">Executor</a> <a class="xa" name="executor"/><a href="/source/s?refs=executor" class="xa">executor</a>,
<a class="l" name="29" href="#29">29</a>			<a href="/source/s?defs=String">String</a> <a class="d" href="#keyword">keyword</a>, <a href="/source/s?defs=String">String</a> <a class="d" href="#triedPath">triedPath</a>) {
<a class="hl" name="30" href="#30">30</a>		<b>boolean</b> <a href="/source/s?defs=ret">ret</a> = <b>true</b>;
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a>		<a class="d" href="#executor">executor</a>.<a href="/source/s?defs=exec">exec</a>(<b>false</b>);
<a class="l" name="33" href="#33">33</a>		<a href="/source/s?defs=String">String</a> <a href="/source/s?defs=output">output</a> = <a class="d" href="#executor">executor</a>.<a href="/source/s?defs=getOutputString">getOutputString</a>();
<a class="l" name="34" href="#34">34</a>		<b>if</b> (<a href="/source/s?defs=output">output</a> == <a href="/source/s?defs=null">null</a> || <a href="/source/s?defs=output">output</a>.<a href="/source/s?defs=indexOf">indexOf</a>(<a class="d" href="#keyword">keyword</a>) == -<span class="n">1</span>) {
<a class="l" name="35" href="#35">35</a>			<a class="d" href="#log">log</a>.<a class="d" href="#log">log</a>(<a href="/source/s?defs=Level">Level</a>.<a href="/source/s?defs=SEVERE">SEVERE</a>, <span class="s">"Error: No {0} found in PATH!\n"</span>
<a class="l" name="36" href="#36">36</a>					+ <span class="s">"(tried running "</span> + <span class="s">"{1}"</span> + <span class="s">")"</span>, <b>new</b> <a href="/source/s?defs=String">String</a>[] { <a class="d" href="#keyword">keyword</a>,
<a class="l" name="37" href="#37">37</a>					<a class="d" href="#triedPath">triedPath</a> });
<a class="l" name="38" href="#38">38</a>			<a href="/source/s?defs=ret">ret</a> = <b>false</b>;
<a class="l" name="39" href="#39">39</a>		}
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>		<b>return</b> <a href="/source/s?defs=ret">ret</a>;
<a class="l" name="42" href="#42">42</a>	}
<a class="l" name="43" href="#43">43</a>
<a class="l" name="44" href="#44">44</a>	<b>public</b> <b>static</b> <b>boolean</b> <a class="xmt" name="validateGit"/><a href="/source/s?refs=validateGit" class="xmt">validateGit</a>() {
<a class="l" name="45" href="#45">45</a>		<b>return</b> <a class="d" href="#validateCommandHelper">validateCommandHelper</a>(<b>new</b> <a href="/source/s?defs=Executor">Executor</a>(<b>new</b> <a href="/source/s?defs=String">String</a>[] { <a class="d" href="#getGit">getGit</a>(),
<a class="l" name="46" href="#46">46</a>				<span class="s">"--version"</span> }), <span class="s">"git"</span>, <a class="d" href="#getGit">getGit</a>());
<a class="l" name="47" href="#47">47</a>	}
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>	<b>public</b> <b>static</b> <b>boolean</b> <a class="xmt" name="validateOpenGrok"/><a href="/source/s?refs=validateOpenGrok" class="xmt">validateOpenGrok</a>() {
<a class="hl" name="50" href="#50">50</a>		<b>return</b> <a class="d" href="#validateCommandHelper">validateCommandHelper</a>(<b>new</b> <a href="/source/s?defs=Executor">Executor</a>(<b>new</b> <a href="/source/s?defs=String">String</a>[] { <a class="d" href="#getJava">getJava</a>(),
<a class="l" name="51" href="#51">51</a>				<span class="s">"-jar"</span>, <a class="d" href="#getOpengrok">getOpengrok</a>(), <span class="s">"-V"</span> }), <span class="s">"OpenGrok"</span>, <a class="d" href="#getJava">getJava</a>());
<a class="l" name="52" href="#52">52</a>	}
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>	<b>public</b> <b>static</b> <b>boolean</b> <a class="xmt" name="validateExuberantCtags"/><a href="/source/s?refs=validateExuberantCtags" class="xmt">validateExuberantCtags</a>() {
<a class="l" name="55" href="#55">55</a>		<b>return</b> <a class="d" href="#validateCommandHelper">validateCommandHelper</a>(<b>new</b> <a href="/source/s?defs=Executor">Executor</a>(<b>new</b> <a href="/source/s?defs=String">String</a>[] { <a class="d" href="#getCtags">getCtags</a>(),
<a class="l" name="56" href="#56">56</a>				<span class="s">"--version"</span> }), <span class="s">"Exuberant Ctags"</span>, <a class="d" href="#getCtags">getCtags</a>());
<a class="l" name="57" href="#57">57</a>	}
<a class="l" name="58" href="#58">58</a>}
<a class="l" name="59" href="#59">59</a>