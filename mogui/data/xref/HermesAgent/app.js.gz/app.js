<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["Indexer",2],["start_deployer",21],["start_enlister",19],["start_indexer",20],["started",22]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">// <a href="/source/s?path=worker.js">worker.js</a></span>
<a class="l" name="2" href="#2">2</a><b>var</b> <a class="xv" name="Indexer"/><a href="/source/s?refs=Indexer" class="xv">Indexer</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'./indexer'</span>)
<a class="l" name="3" href="#3">3</a>  , <a href="/source/s?defs=Enlister">Enlister</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'./enlister'</span>)
<a class="l" name="4" href="#4">4</a>  , <a href="/source/s?defs=Deployer">Deployer</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'./deployer'</span>)
<a class="l" name="5" href="#5">5</a>  , <a href="/source/s?defs=path">path</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'path'</span>);
<a class="l" name="6" href="#6">6</a><b>var</b> <a href="/source/s?defs=server_config">server_config</a> = {
<a class="l" name="7" href="#7">7</a>                        <a href="/source/s?defs=enlist_url">enlist_url</a>: <span class="s">'tcp://127.0.0.1:3000'</span>,
<a class="l" name="8" href="#8">8</a>                        <a href="/source/s?defs=index_url">index_url</a>: <span class="s">'tcp://127.0.0.1:3001'</span>,
<a class="l" name="9" href="#9">9</a>                        <a href="/source/s?defs=deploy_url">deploy_url</a>: <span class="s">'tcp://127.0.0.1:3002'</span>,
<a class="hl" name="10" href="#10">10</a>                        <a href="/source/s?defs=root_folder">root_folder</a>: <a href="/source/s?defs=path">path</a>.<a href="/source/s?defs=resolve">resolve</a>(<a href="/source/s?defs=path">path</a>.<a href="/source/s?defs=join">join</a>(<a href="/source/s?defs=__dirname">__dirname</a>, <span class="s">'..'</span>, <span class="s">'tmp'</span>)),
<a class="l" name="11" href="#11">11</a>                        <a href="/source/s?defs=opengrok_path">opengrok_path</a>: <span class="s">'C:\\Users\\Chundong\\workspace\\OpenGrok\\dist\\opengrok.jar'</span>,
<a class="l" name="12" href="#12">12</a>                        <a href="/source/s?defs=opengrok_war">opengrok_war</a>: <span class="s">'C:\\Users\\Chundong\\workspace\\OpenGrok\\dist\\source.war'</span>,
<a class="l" name="13" href="#13">13</a>                        <a href="/source/s?defs=ctags_path">ctags_path</a>: <span class="s">'C:\\tools\\ctags58\\ctags.exe'</span>,
<a class="l" name="14" href="#14">14</a>                        <a href="/source/s?defs=tomcat_auth">tomcat_auth</a>: <span class="s">'jewelry:hegara'</span>,
<a class="l" name="15" href="#15">15</a>                        <a href="/source/s?defs=tomcat_hostname">tomcat_hostname</a>: <span class="s">'localhost'</span>,
<a class="l" name="16" href="#16">16</a>                        <a href="/source/s?defs=tomcat_port">tomcat_port</a>: <span class="n">8080</span>,
<a class="l" name="17" href="#17">17</a>                    };
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a><b>var</b> <a class="xv" name="start_enlister"/><a href="/source/s?refs=start_enlister" class="xv">start_enlister</a> = <b>false</b>;
<a class="hl" name="20" href="#20">20</a><b>var</b> <a class="xv" name="start_indexer"/><a href="/source/s?refs=start_indexer" class="xv">start_indexer</a> = <b>false</b>;
<a class="l" name="21" href="#21">21</a><b>var</b> <a class="xv" name="start_deployer"/><a href="/source/s?refs=start_deployer" class="xv">start_deployer</a> = <b>false</b>;
<a class="l" name="22" href="#22">22</a><b>var</b> <a class="xv" name="started"/><a href="/source/s?refs=started" class="xv">started</a> = <b>false</b>;
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a><a href="/source/s?defs=process">process</a>.<a href="/source/s?defs=argv">argv</a>.<a href="/source/s?defs=forEach">forEach</a>(<b>function</b> (v, i, <a href="/source/s?defs=argv">argv</a>) {
<a class="l" name="25" href="#25">25</a>    <b>if</b> (i&lt;<span class="n">2</span>) <b>return</b>;
<a class="l" name="26" href="#26">26</a>    <b>if</b> (v === <span class="s">"enlist"</span>) <a class="d" href="#start_enlister">start_enlister</a> = <b>true</b>;
<a class="l" name="27" href="#27">27</a>    <b>else</b> <b>if</b> (v === <span class="s">"index"</span>) <a class="d" href="#start_indexer">start_indexer</a> = <b>true</b>;
<a class="l" name="28" href="#28">28</a>    <b>else</b> <b>if</b> (v === <span class="s">"deploy"</span>) <a class="d" href="#start_deployer">start_deployer</a> = <b>true</b>;
<a class="l" name="29" href="#29">29</a>});
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a><b>if</b> (<a href="/source/s?defs=process">process</a>.<a href="/source/s?defs=argv">argv</a>.<a href="/source/s?defs=length">length</a>&lt;<span class="n">3</span>) {
<a class="l" name="32" href="#32">32</a>    <span class="c">// nothing started. by default kick off all</span>
<a class="l" name="33" href="#33">33</a>    <a class="d" href="#start_enlister">start_enlister</a> = <b>true</b>;
<a class="l" name="34" href="#34">34</a>    <a class="d" href="#start_indexer">start_indexer</a> = <b>true</b>;
<a class="l" name="35" href="#35">35</a>    <a class="d" href="#start_deployer">start_deployer</a> = <b>true</b>;
<a class="l" name="36" href="#36">36</a>}
<a class="l" name="37" href="#37">37</a>
<a class="l" name="38" href="#38">38</a><b>if</b> (<a class="d" href="#start_enlister">start_enlister</a>) {
<a class="l" name="39" href="#39">39</a>    <a href="/source/s?defs=Enlister">Enlister</a>.<a href="/source/s?defs=start_service">start_service</a>(<a href="/source/s?defs=server_config">server_config</a>, <b>function</b>(<a href="/source/s?defs=err">err</a>){
<a class="hl" name="40" href="#40">40</a>        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=error">error</a>(<span class="s">'enlist service error:\n'</span>+<a href="/source/s?defs=err">err</a>);
<a class="l" name="41" href="#41">41</a>    });
<a class="l" name="42" href="#42">42</a>    <a class="d" href="#started">started</a> = <b>true</b>;
<a class="l" name="43" href="#43">43</a>}
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a><b>if</b> (<a class="d" href="#start_indexer">start_indexer</a>) {
<a class="l" name="46" href="#46">46</a>    <a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=start_service">start_service</a>(<a href="/source/s?defs=server_config">server_config</a>, <b>function</b>(<a href="/source/s?defs=err">err</a>){
<a class="l" name="47" href="#47">47</a>        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=error">error</a>(<span class="s">'index service error:\n'</span>+<a href="/source/s?defs=err">err</a>);
<a class="l" name="48" href="#48">48</a>    });
<a class="l" name="49" href="#49">49</a>    <a class="d" href="#started">started</a> = <b>true</b>;
<a class="hl" name="50" href="#50">50</a>}
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a><b>if</b> (<a class="d" href="#start_deployer">start_deployer</a>) {
<a class="l" name="53" href="#53">53</a>    <a href="/source/s?defs=Deployer">Deployer</a>.<a href="/source/s?defs=start_service">start_service</a>(<a href="/source/s?defs=server_config">server_config</a>, <b>function</b>(<a href="/source/s?defs=err">err</a>){
<a class="l" name="54" href="#54">54</a>        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=error">error</a>(<span class="s">'deploy service error:\n'</span>+<a href="/source/s?defs=err">err</a>);
<a class="l" name="55" href="#55">55</a>    });
<a class="l" name="56" href="#56">56</a>    <a class="d" href="#started">started</a> = <b>true</b>;
<a class="l" name="57" href="#57">57</a>}
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a><b>if</b> (!<a class="d" href="#started">started</a>) {
<a class="hl" name="60" href="#60">60</a>    <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=error">error</a>(<span class="s">'Nothing started. exiting...'</span>);
<a class="l" name="61" href="#61">61</a>    <a href="/source/s?defs=process">process</a>.<a href="/source/s?defs=exit">exit</a>(<span class="n">0</span>);
<a class="l" name="62" href="#62">62</a>}