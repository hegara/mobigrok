<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["rl",15],["zmq",2]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">// <a href="/source/s?path=producer.js">producer.js</a></span>
<a class="l" name="2" href="#2">2</a><b>var</b> <a class="xv" name="zmq"/><a href="/source/s?refs=zmq" class="xv">zmq</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'zmq'</span>)
<a class="l" name="3" href="#3">3</a>  , <a href="/source/s?defs=readline">readline</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'readline'</span>)
<a class="l" name="4" href="#4">4</a>  , <a href="/source/s?defs=sock_enlist">sock_enlist</a> = <a class="d" href="#zmq">zmq</a>.<a href="/source/s?defs=socket">socket</a>(<span class="s">'push'</span>);
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a><a href="/source/s?defs=sock_enlist">sock_enlist</a>.<a href="/source/s?defs=bindSync">bindSync</a>(<span class="s">'tcp://127.0.0.1:3000'</span>);
<a class="l" name="7" href="#7">7</a><a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=log">log</a>(<span class="s">'Enlist queue bound to port 3000'</span>);
<a class="l" name="8" href="#8">8</a><span class="c">/*
<a class="l" name="9" href="#9">9</a>setInterval(function(){
<a class="hl" name="10" href="#10">10</a>    var value = Math.floor(Math.random()*100);
<a class="l" name="11" href="#11">11</a>    console.log('sending enlist task of '+value);
<a class="l" name="12" href="#12">12</a>    sock_enlist.send(['name'+value,'url','type']);
<a class="l" name="13" href="#13">13</a>}, 500);
<a class="l" name="14" href="#14">14</a>*/</span>
<a class="l" name="15" href="#15">15</a><b>var</b> <a class="xv" name="rl"/><a href="/source/s?refs=rl" class="xv">rl</a> = <a href="/source/s?defs=readline">readline</a>.<a href="/source/s?defs=createInterface">createInterface</a>(<a href="/source/s?defs=process">process</a>.<a href="/source/s?defs=stdin">stdin</a>, <a href="/source/s?defs=process">process</a>.<a href="/source/s?defs=stdout">stdout</a>);
<a class="l" name="16" href="#16">16</a><a class="d" href="#rl">rl</a>.<a href="/source/s?defs=setPrompt">setPrompt</a>(<span class="s">'&gt; '</span>);
<a class="l" name="17" href="#17">17</a><a class="d" href="#rl">rl</a>.<a href="/source/s?defs=prompt">prompt</a>();
<a class="l" name="18" href="#18">18</a><a class="d" href="#rl">rl</a>.<a href="/source/s?defs=on">on</a>(<span class="s">'line'</span>, <b>function</b>(<a href="/source/s?defs=line">line</a>) {
<a class="l" name="19" href="#19">19</a>    <b>if</b> (<a href="/source/s?defs=line">line</a> === <span class="s">"close"</span> || <a href="/source/s?defs=line">line</a> === <span class="s">"end"</span> || <a href="/source/s?defs=line">line</a> === <span class="s">"exit"</span>) <a class="d" href="#rl">rl</a>.<a href="/source/s?defs=close">close</a>();
<a class="hl" name="20" href="#20">20</a>    <b>else</b> <b>if</b> (<a href="/source/s?defs=line">line</a>.<a href="/source/s?defs=match">match</a>(<span class="s">"^enlist"</span>)) {
<a class="l" name="21" href="#21">21</a>        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=log">log</a>(<span class="s">"enlist requested..."</span>);
<a class="l" name="22" href="#22">22</a>        <a href="/source/s?defs=args">args</a> = <a href="/source/s?defs=line">line</a>.<a href="/source/s?defs=split">split</a>(<span class="s">" "</span>);
<a class="l" name="23" href="#23">23</a>        <b>if</b> (<a href="/source/s?defs=args">args</a>.<a href="/source/s?defs=length">length</a> &gt;= <span class="n">3</span>) {
<a class="l" name="24" href="#24">24</a>            <b>var</b> <a href="/source/s?defs=name">name</a> = <a href="/source/s?defs=args">args</a>[<span class="n">1</span>].<a href="/source/s?defs=toString">toString</a>();
<a class="l" name="25" href="#25">25</a>            <b>var</b> <a href="/source/s?defs=url">url</a> = <a href="/source/s?defs=args">args</a>[<span class="n">2</span>].<a href="/source/s?defs=toString">toString</a>();
<a class="l" name="26" href="#26">26</a>            <b>var</b> <a href="/source/s?defs=type">type</a> = <a href="/source/s?defs=args">args</a>[<span class="n">3</span>]?<a href="/source/s?defs=args">args</a>[<span class="n">3</span>].<a href="/source/s?defs=toString">toString</a>():<span class="s">"git"</span>;
<a class="l" name="27" href="#27">27</a>            <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=log">log</a>(<span class="s">'sending enlist task of '</span>+<a href="/source/s?defs=name">name</a>);
<a class="l" name="28" href="#28">28</a>            <a href="/source/s?defs=sock_enlist">sock_enlist</a>.<a href="/source/s?defs=send">send</a>([<a href="/source/s?defs=name">name</a>, <a href="/source/s?defs=url">url</a>, <a href="/source/s?defs=type">type</a>]);
<a class="l" name="29" href="#29">29</a>        } <b>else</b> {
<a class="hl" name="30" href="#30">30</a>            <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=log">log</a>(<span class="s">"enlist &lt;name&gt; &lt;url&gt; [&lt;type&gt;]"</span>);
<a class="l" name="31" href="#31">31</a>        }
<a class="l" name="32" href="#32">32</a>    }
<a class="l" name="33" href="#33">33</a>    <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=log">log</a>(<span class="s">"\n"</span>);
<a class="l" name="34" href="#34">34</a>    <a class="d" href="#rl">rl</a>.<a href="/source/s?defs=prompt">prompt</a>();
<a class="l" name="35" href="#35">35</a>}).<a href="/source/s?defs=on">on</a>(<span class="s">'close'</span>,<b>function</b>(){
<a class="l" name="36" href="#36">36</a>    <a href="/source/s?defs=process">process</a>.<a href="/source/s?defs=exit">exit</a>(<span class="n">0</span>);
<a class="l" name="37" href="#37">37</a>});
<a class="l" name="38" href="#38">38</a>