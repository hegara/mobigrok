<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["zmq",1]]],["Class","xc",[["Indexer",23]]],["Function","xf",[["Indexer.create",114],["Indexer.start_service",124]]],["Method","xmt",[["Indexer.generateWebXml",98],["Indexer.index",69],["Indexer.prepare",23]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>var</b> <a class="xv" name="zmq"/><a href="/source/s?refs=zmq" class="xv">zmq</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'zmq'</span>)
<a class="l" name="2" href="#2">2</a>  , <a href="/source/s?defs=path">path</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'path'</span>)
<a class="l" name="3" href="#3">3</a>  , <a href="/source/s?defs=fs">fs</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'fs'</span>)
<a class="l" name="4" href="#4">4</a>  , <a href="/source/s?defs=mkdirp">mkdirp</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'mkdirp'</span>)
<a class="l" name="5" href="#5">5</a>  , <a href="/source/s?defs=sock_index">sock_index</a> = <a class="d" href="#zmq">zmq</a>.<a href="/source/s?defs=socket">socket</a>(<span class="s">'pull'</span>)
<a class="l" name="6" href="#6">6</a>  , <a href="/source/s?defs=sock_deploy">sock_deploy</a> = <a class="d" href="#zmq">zmq</a>.<a href="/source/s?defs=socket">socket</a>(<span class="s">'push'</span>)
<a class="l" name="7" href="#7">7</a>  , <a href="/source/s?defs=spawn">spawn</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'child_process'</span>).<a href="/source/s?defs=spawn">spawn</a>;
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a><span class="c">// private constructor:</span>
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a><b>var</b> <a class="d" href="#Indexer">Indexer</a> = <a href="/source/s?defs=module">module</a>.<a href="/source/s?defs=exports">exports</a> = <b>function</b> <a class="d" href="#Indexer">Indexer</a>(<a href="/source/s?defs=name">name</a>, <a href="/source/s?defs=source">source</a>, <a href="/source/s?defs=target">target</a>) {
<a class="l" name="12" href="#12">12</a>    <b>this</b>.<a href="/source/s?defs=_name">_name</a> = <a href="/source/s?defs=name">name</a>;
<a class="l" name="13" href="#13">13</a>    <b>this</b>.<a href="/source/s?defs=_source">_source</a> = <a href="/source/s?defs=source">source</a>;
<a class="l" name="14" href="#14">14</a>    <b>this</b>.<a href="/source/s?defs=_target">_target</a> = <a href="/source/s?defs=target">target</a>;
<a class="l" name="15" href="#15">15</a>    <b>this</b>.<a href="/source/s?defs=_config">_config</a> = <b>null</b>;
<a class="l" name="16" href="#16">16</a>};
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a><a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=OpenGrokPath">OpenGrokPath</a> = <b>null</b>;
<a class="l" name="19" href="#19">19</a><a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=CtagsPath">CtagsPath</a> = <b>null</b>;
<a class="hl" name="20" href="#20">20</a><a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=TemplateXml">TemplateXml</a> = <a href="/source/s?defs=path">path</a>.<a href="/source/s?defs=join">join</a>(<a href="/source/s?defs=__dirname">__dirname</a>,<span class="s">'<a href="/source/s?path=web.xml">web.xml</a>'</span>);
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">// use callback for error reporting or return the object</span>
<a class="l" name="23" href="#23">23</a><a class="xc" name="Indexer"/><a href="/source/s?refs=Indexer" class="xc">Indexer</a>.<a href="/source/s?defs=prototype">prototype</a>.<a href="/source/s?defs=prepare">prepare</a> = <b>function</b>(<a href="/source/s?defs=callback">callback</a>) {
<a class="l" name="24" href="#24">24</a>    <span class="c">// 1. check data legitimacy (source existence, target write access, etc.)</span>
<a class="l" name="25" href="#25">25</a>    <b>var</b> <a href="/source/s?defs=indexer">indexer</a> = <b>this</b>;
<a class="l" name="26" href="#26">26</a>    <a href="/source/s?defs=fs">fs</a>.<a href="/source/s?defs=exists">exists</a>(<a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_source">_source</a>, <b>function</b> (<a href="/source/s?defs=exists">exists</a>) {
<a class="l" name="27" href="#27">27</a>        <b>if</b> (!<a href="/source/s?defs=exists">exists</a>) <a href="/source/s?defs=callback">callback</a>(<span class="s">'Cannot find source!'</span>+<a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_source">_source</a>);
<a class="l" name="28" href="#28">28</a>        <b>else</b> {
<a class="l" name="29" href="#29">29</a>            <span class="c">// 2. check the existence of tools (jre, opengrok, etc.)</span>
<a class="hl" name="30" href="#30">30</a>            <a href="/source/s?defs=fs">fs</a>.<a href="/source/s?defs=exists">exists</a>(<a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=OpenGrokPath">OpenGrokPath</a>, <b>function</b> (<a href="/source/s?defs=exists">exists</a>) {
<a class="l" name="31" href="#31">31</a>                <b>if</b> (!<a href="/source/s?defs=exists">exists</a>) <a href="/source/s?defs=callback">callback</a>(<span class="s">'Cannot find opengrok!'</span>+<a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=OpenGrokPath">OpenGrokPath</a>);
<a class="l" name="32" href="#32">32</a>                <b>else</b> {
<a class="l" name="33" href="#33">33</a>                    <b>var</b> <a href="/source/s?defs=java_version">java_version</a> = <a href="/source/s?defs=spawn">spawn</a>(<span class="s">"java"</span>, [<span class="s">"-version"</span>]);
<a class="l" name="34" href="#34">34</a>                    <b>var</b> <a href="/source/s?defs=received_java_version">received_java_version</a> = <b>false</b>;
<a class="l" name="35" href="#35">35</a>                    <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">'checking java_version: '</span>+<a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=OpenGrokPath">OpenGrokPath</a>);
<a class="l" name="36" href="#36">36</a>                    <a href="/source/s?defs=java_version">java_version</a>.<a href="/source/s?defs=stderr">stderr</a>.<a href="/source/s?defs=on">on</a>(<span class="s">'data'</span>, <b>function</b>(<a href="/source/s?defs=data">data</a>){
<a class="l" name="37" href="#37">37</a>                        <span class="c">// we only care the first line.</span>
<a class="l" name="38" href="#38">38</a>                        <b>if</b> (<a href="/source/s?defs=received_java_version">received_java_version</a>) <b>return</b>;
<a class="l" name="39" href="#39">39</a>                        <a href="/source/s?defs=received_java_version">received_java_version</a> = <b>true</b>;
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>                        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">'java_version result back: '</span>+<a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=toString">toString</a>());
<a class="l" name="42" href="#42">42</a>                        <b>var</b> <a href="/source/s?defs=stdout_text">stdout_text</a> = <a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=toString">toString</a>();
<a class="l" name="43" href="#43">43</a>                        <span class="c">// TODO: check version number?</span>
<a class="l" name="44" href="#44">44</a>                        <b>if</b> (<a href="/source/s?defs=stdout_text">stdout_text</a>.<a href="/source/s?defs=match">match</a>(<span class="s">"^java version \"[0-9]+\.[0-9]+"</span>)) {
<a class="l" name="45" href="#45">45</a>                            <span class="c">// 3. make directory</span>
<a class="l" name="46" href="#46">46</a>                            <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">'to make dir: '</span>+<a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_target">_target</a>)
<a class="l" name="47" href="#47">47</a>                            <a href="/source/s?defs=mkdirp">mkdirp</a>(<a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_target">_target</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="48" href="#48">48</a>                                <b>if</b> (<a href="/source/s?defs=err">err</a>) <a href="/source/s?defs=callback">callback</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="49" href="#49">49</a>                                <b>else</b> {
<a class="hl" name="50" href="#50">50</a>                                    <a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_config">_config</a> = <a href="/source/s?defs=path">path</a>.<a href="/source/s?defs=resolve">resolve</a>(<a href="/source/s?defs=path">path</a>.<a href="/source/s?defs=join">join</a>(<a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_target">_target</a>, <span class="s">"<a href="/source/s?path=configuration.xml">configuration.xml</a>"</span>));
<a class="l" name="51" href="#51">51</a>                                    <span class="c">// 4. ready to index!</span>
<a class="l" name="52" href="#52">52</a>                                    <a href="/source/s?defs=callback">callback</a>(<b>null</b>, <a href="/source/s?defs=indexer">indexer</a>);
<a class="l" name="53" href="#53">53</a>                                }
<a class="l" name="54" href="#54">54</a>                            });
<a class="l" name="55" href="#55">55</a>                        } <b>else</b> {
<a class="l" name="56" href="#56">56</a>                            <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=warn">warn</a>(<span class="s">"Dropped the ball!! Cannot find proper version of java."</span>);
<a class="l" name="57" href="#57">57</a>                            <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=warn">warn</a>(<span class="s">"  got: "</span>+<a href="/source/s?defs=stdout_text">stdout_text</a>);
<a class="l" name="58" href="#58">58</a>                            <a href="/source/s?defs=callback">callback</a>(<span class="s">"Cannot find proper version of java. Found: "</span>+<a href="/source/s?defs=stdout_text">stdout_text</a>);
<a class="l" name="59" href="#59">59</a>                            <b>return</b>;
<a class="hl" name="60" href="#60">60</a>                        }
<a class="l" name="61" href="#61">61</a>                    });
<a class="l" name="62" href="#62">62</a>                }
<a class="l" name="63" href="#63">63</a>            });
<a class="l" name="64" href="#64">64</a>        }
<a class="l" name="65" href="#65">65</a>    });
<a class="l" name="66" href="#66">66</a>};
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a><span class="c">// index the source code with opengrok</span>
<a class="l" name="69" href="#69">69</a><a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=prototype">prototype</a>.<a href="/source/s?defs=index">index</a> = <b>function</b>(<a href="/source/s?defs=callback">callback</a>) {
<a class="hl" name="70" href="#70">70</a>    <b>var</b> <a href="/source/s?defs=indexer">indexer</a> = <b>this</b>;
<a class="l" name="71" href="#71">71</a>    <span class="c">// call opengrok to index</span>
<a class="l" name="72" href="#72">72</a>    <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">"Indexing "</span>+<a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_source">_source</a>+<span class="s">" to "</span>+<a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_target">_target</a>);
<a class="l" name="73" href="#73">73</a>    <b>var</b> <a href="/source/s?defs=opengrok_index">opengrok_index</a> = <a href="/source/s?defs=spawn">spawn</a>(<span class="s">"java"</span>, [<span class="s">"-jar"</span>, <a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=OpenGrokPath">OpenGrokPath</a>,
<a class="l" name="74" href="#74">74</a>                <span class="s">"-c"</span>, <a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=CtagsPath">CtagsPath</a>, <span class="s">"-d"</span>, <a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_target">_target</a>, <span class="s">"-s"</span>, <a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_source">_source</a>,
<a class="l" name="75" href="#75">75</a>                <span class="s">"-W"</span>, <a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_config">_config</a>, <span class="s">"-v"</span>]);
<a class="l" name="76" href="#76">76</a>    <a href="/source/s?defs=opengrok_index">opengrok_index</a>.<a href="/source/s?defs=stdout">stdout</a>.<a href="/source/s?defs=on">on</a>(<span class="s">'data'</span>, <b>function</b>(<a href="/source/s?defs=data">data</a>) {
<a class="l" name="77" href="#77">77</a>        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=toString">toString</a>());
<a class="l" name="78" href="#78">78</a>    });
<a class="l" name="79" href="#79">79</a>    <a href="/source/s?defs=opengrok_index">opengrok_index</a>.<a href="/source/s?defs=stderr">stderr</a>.<a href="/source/s?defs=on">on</a>(<span class="s">'data'</span>, <b>function</b>(<a href="/source/s?defs=data">data</a>) {
<a class="hl" name="80" href="#80">80</a>        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=error">error</a>(<a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=toString">toString</a>());
<a class="l" name="81" href="#81">81</a>    });
<a class="l" name="82" href="#82">82</a>    <a href="/source/s?defs=opengrok_index">opengrok_index</a>.<a href="/source/s?defs=on">on</a>(<span class="s">'close'</span>, <b>function</b>(<a href="/source/s?defs=code">code</a>) {
<a class="l" name="83" href="#83">83</a>        <b>if</b> (<a href="/source/s?defs=code">code</a> !== <span class="n">0</span>) {
<a class="l" name="84" href="#84">84</a>            <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=log">log</a>(<span class="s">'Indexing process exited with code '</span> + <a href="/source/s?defs=code">code</a>);
<a class="l" name="85" href="#85">85</a>            <a href="/source/s?defs=callback">callback</a>(<span class="s">'Indexing process exited with code '</span> + <a href="/source/s?defs=code">code</a>);
<a class="l" name="86" href="#86">86</a>        } <b>else</b> {
<a class="l" name="87" href="#87">87</a>            <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">"Index done with code: "</span>+<a href="/source/s?defs=code">code</a>+<span class="s">" under "</span>+<a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_config">_config</a>);
<a class="l" name="88" href="#88">88</a>            <a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=generateWebXml">generateWebXml</a>(<a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=TemplateXml">TemplateXml</a>, <b>function</b>(<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=result">result</a>){
<a class="l" name="89" href="#89">89</a>                <b>if</b> (<a href="/source/s?defs=err">err</a>) <a href="/source/s?defs=callback">callback</a>(<a href="/source/s?defs=err">err</a>);
<a class="hl" name="90" href="#90">90</a>                <b>else</b> {
<a class="l" name="91" href="#91">91</a>                    <a href="/source/s?defs=callback">callback</a>(<b>null</b>, <a href="/source/s?defs=result">result</a>);
<a class="l" name="92" href="#92">92</a>                }
<a class="l" name="93" href="#93">93</a>            });
<a class="l" name="94" href="#94">94</a>        }
<a class="l" name="95" href="#95">95</a>    });
<a class="l" name="96" href="#96">96</a>};
<a class="l" name="97" href="#97">97</a>
<a class="l" name="98" href="#98">98</a><a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=prototype">prototype</a>.<a href="/source/s?defs=generateWebXml">generateWebXml</a> = <b>function</b>(<a href="/source/s?defs=template_xml">template_xml</a>, <a href="/source/s?defs=callback">callback</a>) {
<a class="l" name="99" href="#99">99</a>    <b>var</b> <a href="/source/s?defs=indexer">indexer</a> = <b>this</b>;
<a class="hl" name="100" href="#100">100</a>    <a href="/source/s?defs=fs">fs</a>.<a href="/source/s?defs=readFile">readFile</a>(<a href="/source/s?defs=template_xml">template_xml</a>, <b>function</b>(<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=data">data</a>){
<a class="l" name="101" href="#101">101</a>        <b>var</b> <a href="/source/s?defs=newContent">newContent</a> = <a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=toString">toString</a>()
<a class="l" name="102" href="#102">102</a>                             .<a href="/source/s?defs=replace">replace</a>(<span class="s">'{config}'</span>, <a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_config">_config</a>)
<a class="l" name="103" href="#103">103</a>                             .<a href="/source/s?defs=replace">replace</a>(<span class="s">'{src_root}'</span>, <a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_source">_source</a>)
<a class="l" name="104" href="#104">104</a>                             .<a href="/source/s?defs=replace">replace</a>(<span class="s">'{index_root}'</span>, <a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_target">_target</a>);
<a class="l" name="105" href="#105">105</a>        <a href="/source/s?defs=fs">fs</a>.<a href="/source/s?defs=writeFile">writeFile</a>(<a href="/source/s?defs=path">path</a>.<a href="/source/s?defs=join">join</a>(<a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=_target">_target</a>, <span class="s">'<a href="/source/s?path=web.xml">web.xml</a>'</span>), <a href="/source/s?defs=newContent">newContent</a>, <b>function</b>(<a href="/source/s?defs=err">err</a>){
<a class="l" name="106" href="#106">106</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <a href="/source/s?defs=callback">callback</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="107" href="#107">107</a>            <b>else</b> {
<a class="l" name="108" href="#108">108</a>                <a href="/source/s?defs=callback">callback</a>(<b>null</b>, <a href="/source/s?defs=indexer">indexer</a>);
<a class="l" name="109" href="#109">109</a>            }
<a class="hl" name="110" href="#110">110</a>        });
<a class="l" name="111" href="#111">111</a>    });
<a class="l" name="112" href="#112">112</a>};
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a><a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=create">create</a> = <b>function</b>(<a href="/source/s?defs=data">data</a>, <a href="/source/s?defs=callback">callback</a>) {
<a class="l" name="115" href="#115">115</a>    <b>var</b> <a href="/source/s?defs=indexer">indexer</a> = <b>new</b> <a class="d" href="#Indexer">Indexer</a>(<a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=name">name</a>, <a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=source">source</a>, <a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=target">target</a>);
<a class="l" name="116" href="#116">116</a>    <a href="/source/s?defs=indexer">indexer</a>.<a href="/source/s?defs=prepare">prepare</a>(<b>function</b>(<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=result">result</a>){
<a class="l" name="117" href="#117">117</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <a href="/source/s?defs=callback">callback</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="118" href="#118">118</a>        <b>else</b> {
<a class="l" name="119" href="#119">119</a>            <a href="/source/s?defs=callback">callback</a>(<b>null</b>, <a href="/source/s?defs=result">result</a>);
<a class="hl" name="120" href="#120">120</a>        }
<a class="l" name="121" href="#121">121</a>    });
<a class="l" name="122" href="#122">122</a>};
<a class="l" name="123" href="#123">123</a>
<a class="l" name="124" href="#124">124</a><a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=start_service">start_service</a> = <b>function</b>(<a href="/source/s?defs=config">config</a>, <a href="/source/s?defs=callback">callback</a>) {
<a class="l" name="125" href="#125">125</a>    <a href="/source/s?defs=sock_index">sock_index</a>.<a href="/source/s?defs=connect">connect</a>(<a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=index_url">index_url</a>);
<a class="l" name="126" href="#126">126</a>    <a href="/source/s?defs=sock_deploy">sock_deploy</a>.<a href="/source/s?defs=bindSync">bindSync</a>(<a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=deploy_url">deploy_url</a>);
<a class="l" name="127" href="#127">127</a>    <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">'Worker connected to index queue: '</span>+<a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=index_url">index_url</a>);
<a class="l" name="128" href="#128">128</a>    <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">'Worker bound to deploy queue: '</span>+<a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=deploy_url">deploy_url</a>);
<a class="l" name="129" href="#129">129</a>    <b>if</b> (!<a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=opengrok_path">opengrok_path</a> || !<a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=opengrok_path">opengrok_path</a>.<a href="/source/s?defs=match">match</a>(<span class="s">'.jar$'</span>)) {
<a class="hl" name="130" href="#130">130</a>        <a href="/source/s?defs=callback">callback</a>(<span class="s">'Require valid opengrok_path to be set!'</span>);
<a class="l" name="131" href="#131">131</a>    } <b>else</b> <b>if</b> (!<a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=ctags_path">ctags_path</a>) {
<a class="l" name="132" href="#132">132</a>        <a href="/source/s?defs=callback">callback</a>(<span class="s">'Require valid ctags_path to be set!'</span>);
<a class="l" name="133" href="#133">133</a>    } <b>else</b> {
<a class="l" name="134" href="#134">134</a>        <a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=OpenGrokPath">OpenGrokPath</a> = <a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=opengrok_path">opengrok_path</a>;
<a class="l" name="135" href="#135">135</a>        <a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=CtagsPath">CtagsPath</a> = <a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=ctags_path">ctags_path</a>;
<a class="l" name="136" href="#136">136</a>        <a href="/source/s?defs=sock_index">sock_index</a>.<a href="/source/s?defs=on">on</a>(<span class="s">'message'</span>, <b>function</b>(<a href="/source/s?defs=name">name</a>, <a href="/source/s?defs=src">src</a>, <a href="/source/s?defs=dst">dst</a>){
<a class="l" name="137" href="#137">137</a>            <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=time">time</a>(<span class="s">'index-'</span>+<a href="/source/s?defs=name">name</a>);
<a class="l" name="138" href="#138">138</a>            <a class="d" href="#Indexer">Indexer</a>.<a href="/source/s?defs=create">create</a>({
<a class="l" name="139" href="#139">139</a>                <a href="/source/s?defs=name">name</a>: <a href="/source/s?defs=name">name</a>.<a href="/source/s?defs=toString">toString</a>(),
<a class="hl" name="140" href="#140">140</a>                <a href="/source/s?defs=source">source</a>:<a href="/source/s?defs=src">src</a>.<a href="/source/s?defs=toString">toString</a>(),
<a class="l" name="141" href="#141">141</a>                <a href="/source/s?defs=target">target</a>:<a href="/source/s?defs=dst">dst</a>.<a href="/source/s?defs=toString">toString</a>()
<a class="l" name="142" href="#142">142</a>            }, <b>function</b>(<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=result">result</a>){
<a class="l" name="143" href="#143">143</a>                <b>if</b> (<a href="/source/s?defs=err">err</a>) <a href="/source/s?defs=callback">callback</a>(<span class="s">'index prepare err\n'</span>+<a href="/source/s?defs=err">err</a>);
<a class="l" name="144" href="#144">144</a>                <a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=index">index</a>(<b>function</b>(<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=result">result</a>){
<a class="l" name="145" href="#145">145</a>                    <b>if</b> (<a href="/source/s?defs=err">err</a>) <a href="/source/s?defs=callback">callback</a>(<span class="s">'index err:\n'</span>+<a href="/source/s?defs=err">err</a>);
<a class="l" name="146" href="#146">146</a>                    <b>else</b> {
<a class="l" name="147" href="#147">147</a>                        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=timeEnd">timeEnd</a>(<span class="s">'index-'</span>+<a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_name">_name</a>);
<a class="l" name="148" href="#148">148</a>                        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">'index worker: %s -&gt; %s'</span>, <a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_source">_source</a>, <a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_target">_target</a>);
<a class="l" name="149" href="#149">149</a>                        <a href="/source/s?defs=sock_deploy">sock_deploy</a>.<a href="/source/s?defs=send">send</a>([<a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_name">_name</a>, <a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_source">_source</a>, <a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_target">_target</a>]);
<a class="hl" name="150" href="#150">150</a>                    }
<a class="l" name="151" href="#151">151</a>                });
<a class="l" name="152" href="#152">152</a>            });
<a class="l" name="153" href="#153">153</a>        });
<a class="l" name="154" href="#154">154</a>    }
<a class="l" name="155" href="#155">155</a>};
<a class="l" name="156" href="#156">156</a>