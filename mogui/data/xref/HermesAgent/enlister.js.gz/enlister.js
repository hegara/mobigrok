<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["zmq",1]]],["Class","xc",[["Enlister",24]]],["Function","xf",[["Enlister.create",101],["Enlister.start_service",110]]],["Method","xmt",[["Enlister.enlist",79],["Enlister.prepare",24]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>var</b> <a class="xv" name="zmq"/><a href="/source/s?refs=zmq" class="xv">zmq</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'zmq'</span>)
<a class="l" name="2" href="#2">2</a>  , <a href="/source/s?defs=path">path</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'path'</span>)
<a class="l" name="3" href="#3">3</a>  , <a href="/source/s?defs=mkdirp">mkdirp</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'mkdirp'</span>)
<a class="l" name="4" href="#4">4</a>  , <a href="/source/s?defs=sock_enlist">sock_enlist</a> = <a class="d" href="#zmq">zmq</a>.<a href="/source/s?defs=socket">socket</a>(<span class="s">'pull'</span>)
<a class="l" name="5" href="#5">5</a>  , <a href="/source/s?defs=sock_index">sock_index</a> = <a class="d" href="#zmq">zmq</a>.<a href="/source/s?defs=socket">socket</a>(<span class="s">'push'</span>)
<a class="l" name="6" href="#6">6</a>  , <a href="/source/s?defs=spawn">spawn</a> = <a href="/source/s?defs=require">require</a>(<span class="s">'child_process'</span>).<a href="/source/s?defs=spawn">spawn</a>;
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a><span class="c">// private constructor:</span>
<a class="l" name="9" href="#9">9</a>
<a class="hl" name="10" href="#10">10</a><b>var</b> <a class="d" href="#Enlister">Enlister</a> = <a href="/source/s?defs=module">module</a>.<a href="/source/s?defs=exports">exports</a> = <b>function</b> <a class="d" href="#Enlister">Enlister</a>(<a href="/source/s?defs=name">name</a>, <a href="/source/s?defs=url">url</a>, <a href="/source/s?defs=type">type</a>) {
<a class="l" name="11" href="#11">11</a>    <b>this</b>.<a href="/source/s?defs=_name">_name</a> = <a href="/source/s?defs=name">name</a>;
<a class="l" name="12" href="#12">12</a>    <b>this</b>.<a href="/source/s?defs=_url">_url</a> = <a href="/source/s?defs=url">url</a>;
<a class="l" name="13" href="#13">13</a>    <b>this</b>.<a href="/source/s?defs=_type">_type</a> = <a href="/source/s?defs=type">type</a>;
<a class="l" name="14" href="#14">14</a>    <b>this</b>.<a href="/source/s?defs=_path">_path</a> = <b>null</b>;
<a class="l" name="15" href="#15">15</a>};
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a><a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=RootFolder">RootFolder</a> = <a href="/source/s?defs=__dirname">__dirname</a>;
<a class="l" name="18" href="#18">18</a><a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=AllowedTypes">AllowedTypes</a> = [<span class="s">"git"</span>, <span class="s">"hg"</span>, <span class="s">"svn"</span>];
<a class="l" name="19" href="#19">19</a><a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=UrlPatterns">UrlPatterns</a> = [<span class="s">"^(http[s]?|git|ssh)://"</span>, <span class="s">"^(http[s]?|ssh)://"</span>, <span class="s">"^(http[s]?|svn)://"</span>];
<a class="hl" name="20" href="#20">20</a><a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=NameRule">NameRule</a> = <span class="s">"[a-zA-Z0-9]+[a-zA-Z0-9\-\_\+]*"</span>;
<a class="l" name="21" href="#21">21</a><a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=MaxNameLength">MaxNameLength</a> = <span class="n">255</span>;
<a class="l" name="22" href="#22">22</a>
<a class="l" name="23" href="#23">23</a><span class="c">// use callback for error reporting or return the object</span>
<a class="l" name="24" href="#24">24</a><a class="xc" name="Enlister"/><a href="/source/s?refs=Enlister" class="xc">Enlister</a>.<a href="/source/s?defs=prototype">prototype</a>.<a href="/source/s?defs=prepare">prepare</a> = <b>function</b>(<a href="/source/s?defs=callback">callback</a>) {
<a class="l" name="25" href="#25">25</a>    <span class="c">// 1. check data legitimacy (url, type, name, etc.)</span>
<a class="l" name="26" href="#26">26</a>    <b>var</b> <a href="/source/s?defs=enlister">enlister</a> = <b>this</b>;
<a class="l" name="27" href="#27">27</a>    <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">"preparing enlister: %j"</span>, <a href="/source/s?defs=enlister">enlister</a>);
<a class="l" name="28" href="#28">28</a>    <b>var</b> <a href="/source/s?defs=idx_type">idx_type</a> = <a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=AllowedTypes">AllowedTypes</a>.<a href="/source/s?defs=indexOf">indexOf</a>(<a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_type">_type</a>);
<a class="l" name="29" href="#29">29</a>    <b>if</b> (<a href="/source/s?defs=idx_type">idx_type</a>&lt;<span class="n">0</span>) {
<a class="hl" name="30" href="#30">30</a>        <a href="/source/s?defs=callback">callback</a>(<span class="s">"Not allowed type: "</span>+<a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_type">_type</a>);
<a class="l" name="31" href="#31">31</a>        <b>return</b>;
<a class="l" name="32" href="#32">32</a>    } <b>else</b> <b>if</b> (!<a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_url">_url</a>.<a href="/source/s?defs=match">match</a>(<a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=UrlPatterns">UrlPatterns</a>[<a href="/source/s?defs=idx_type">idx_type</a>])) {
<a class="l" name="33" href="#33">33</a>        <a href="/source/s?defs=callback">callback</a>(<span class="s">"Not supported url: "</span>+<a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_url">_url</a>+<span class="s">'with pattern: '</span>+<a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=UrlPatterns">UrlPatterns</a>[<a href="/source/s?defs=idx_type">idx_type</a>]);
<a class="l" name="34" href="#34">34</a>        <b>return</b>;
<a class="l" name="35" href="#35">35</a>    } <b>else</b> <b>if</b> (<a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_name">_name</a>.<a href="/source/s?defs=length">length</a>&gt;<a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=MaxNameLength">MaxNameLength</a> || !<a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_name">_name</a>.<a href="/source/s?defs=match">match</a>(<a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=NameRule">NameRule</a>)) {
<a class="l" name="36" href="#36">36</a>        <a href="/source/s?defs=callback">callback</a>(<span class="s">"Invalid name["</span>+<a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_name">_name</a>.<a href="/source/s?defs=length">length</a>+<span class="s">"]: "</span>+<a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_name">_name</a>);
<a class="l" name="37" href="#37">37</a>        <b>return</b>;
<a class="l" name="38" href="#38">38</a>    }
<a class="l" name="39" href="#39">39</a>    <span class="c">// 2. check the existence of tools (git, etc.)</span>
<a class="hl" name="40" href="#40">40</a>    <b>if</b> (<b>this</b>.<a href="/source/s?defs=_type">_type</a> === <span class="s">"git"</span>) {
<a class="l" name="41" href="#41">41</a>        <b>var</b> <a href="/source/s?defs=git_version">git_version</a> = <a href="/source/s?defs=spawn">spawn</a>(<span class="s">"git"</span>, [<span class="s">"--version"</span>]);
<a class="l" name="42" href="#42">42</a>        <b>var</b> <a href="/source/s?defs=received_git_version">received_git_version</a> = <b>false</b>;
<a class="l" name="43" href="#43">43</a>        <a href="/source/s?defs=git_version">git_version</a>.<a href="/source/s?defs=stdout">stdout</a>.<a href="/source/s?defs=on">on</a>(<span class="s">'data'</span>, <b>function</b>(<a href="/source/s?defs=data">data</a>){
<a class="l" name="44" href="#44">44</a>            <span class="c">// we only care the first line.</span>
<a class="l" name="45" href="#45">45</a>            <b>if</b> (<a href="/source/s?defs=received_git_version">received_git_version</a>) <b>return</b>;
<a class="l" name="46" href="#46">46</a>            <a href="/source/s?defs=received_git_version">received_git_version</a> = <b>true</b>;
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a>            <b>var</b> <a href="/source/s?defs=stdout_text">stdout_text</a> = <a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=toString">toString</a>();
<a class="l" name="49" href="#49">49</a>            <b>if</b> (<a href="/source/s?defs=stdout_text">stdout_text</a>.<a href="/source/s?defs=match">match</a>(<span class="s">"^git version [0-9]+\.[0-9]+"</span>)) {
<a class="hl" name="50" href="#50">50</a>                <span class="c">// TODO: check version number?</span>
<a class="l" name="51" href="#51">51</a>                <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">"passed git version check!"</span>);
<a class="l" name="52" href="#52">52</a>                <span class="c">// 3. check the appropriate permission (file access, etc.)</span>
<a class="l" name="53" href="#53">53</a>                <a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_path">_path</a> = <a href="/source/s?defs=path">path</a>.<a href="/source/s?defs=normalize">normalize</a>(<a href="/source/s?defs=path">path</a>.<a href="/source/s?defs=join">join</a>(<a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=RootFolder">RootFolder</a>, <a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_name">_name</a>));
<a class="l" name="54" href="#54">54</a>                <span class="c">// 4. make directory</span>
<a class="l" name="55" href="#55">55</a>                <a href="/source/s?defs=mkdirp">mkdirp</a>(<a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_path">_path</a>, <b>function</b> (<a href="/source/s?defs=err">err</a>) {
<a class="l" name="56" href="#56">56</a>                    <b>if</b> (<a href="/source/s?defs=err">err</a>) <a href="/source/s?defs=callback">callback</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="57" href="#57">57</a>                    <b>else</b> {
<a class="l" name="58" href="#58">58</a>                        <span class="c">// 5. ready to enlist!</span>
<a class="l" name="59" href="#59">59</a>                        <a href="/source/s?defs=callback">callback</a>(<b>null</b>, <a href="/source/s?defs=enlister">enlister</a>);
<a class="hl" name="60" href="#60">60</a>                    }
<a class="l" name="61" href="#61">61</a>                });
<a class="l" name="62" href="#62">62</a>            } <b>else</b> {
<a class="l" name="63" href="#63">63</a>                <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=warn">warn</a>(<span class="s">"Dropped the ball!! Cannot find proper version of git."</span>);
<a class="l" name="64" href="#64">64</a>                <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=warn">warn</a>(<span class="s">"  got: "</span>+<a href="/source/s?defs=stdout_text">stdout_text</a>);
<a class="l" name="65" href="#65">65</a>                <a href="/source/s?defs=callback">callback</a>(<span class="s">"Cannot find proper version of git. Found: "</span>+<a href="/source/s?defs=stdout_text">stdout_text</a>);
<a class="l" name="66" href="#66">66</a>                <b>return</b>;
<a class="l" name="67" href="#67">67</a>            }
<a class="l" name="68" href="#68">68</a>        });
<a class="l" name="69" href="#69">69</a>    <span class="c">// TODO: add <a href="/source/s?path=hg/">hg</a>/<a href="/source/s?path=hg/svn">svn</a> support here.</span>
<a class="hl" name="70" href="#70">70</a>    } <b>else</b> {
<a class="l" name="71" href="#71">71</a>        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=warn">warn</a>(<span class="s">"Unknown type of source"</span>);
<a class="l" name="72" href="#72">72</a>        <a href="/source/s?defs=callback">callback</a>(<span class="s">"Unknown type of source repository: "</span>+<a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_type">_type</a>);
<a class="l" name="73" href="#73">73</a>        <b>return</b>;
<a class="l" name="74" href="#74">74</a>    }
<a class="l" name="75" href="#75">75</a>}
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a><span class="c">// enlist the source code with given type of repo tool</span>
<a class="l" name="78" href="#78">78</a><span class="c">// and return the folder containing the source via callback</span>
<a class="l" name="79" href="#79">79</a><a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=prototype">prototype</a>.<a href="/source/s?defs=enlist">enlist</a> = <b>function</b>(<a href="/source/s?defs=callback">callback</a>) {
<a class="hl" name="80" href="#80">80</a>    <b>var</b> <a href="/source/s?defs=enlister">enlister</a> = <b>this</b>;
<a class="l" name="81" href="#81">81</a>    <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">"Enlisting "</span>+<a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_name">_name</a>+<span class="s">"["</span>+<a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_type">_type</a>+<span class="s">"]:"</span>+<a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_url">_url</a>);
<a class="l" name="82" href="#82">82</a>    <b>var</b> <a href="/source/s?defs=git_clone">git_clone</a> = <a href="/source/s?defs=spawn">spawn</a>(<span class="s">"git"</span>, [<span class="s">"clone"</span>, <span class="s">"--progress"</span>,
<a class="l" name="83" href="#83">83</a>                <span class="s">"--recursive"</span>, <span class="s">"--depth"</span>, <span class="s">"1"</span>, <a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_url">_url</a>, <a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=_path">_path</a>]);
<a class="l" name="84" href="#84">84</a>    <a href="/source/s?defs=git_clone">git_clone</a>.<a href="/source/s?defs=stdout">stdout</a>.<a href="/source/s?defs=on">on</a>(<span class="s">'data'</span>, <b>function</b>(<a href="/source/s?defs=data">data</a>) {
<a class="l" name="85" href="#85">85</a>        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=toString">toString</a>());
<a class="l" name="86" href="#86">86</a>    });
<a class="l" name="87" href="#87">87</a>    <a href="/source/s?defs=git_clone">git_clone</a>.<a href="/source/s?defs=stderr">stderr</a>.<a href="/source/s?defs=on">on</a>(<span class="s">'data'</span>, <b>function</b>(<a href="/source/s?defs=data">data</a>) {
<a class="l" name="88" href="#88">88</a>        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=error">error</a>(<a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=toString">toString</a>());
<a class="l" name="89" href="#89">89</a>    });
<a class="hl" name="90" href="#90">90</a>    <a href="/source/s?defs=git_clone">git_clone</a>.<a href="/source/s?defs=on">on</a>(<span class="s">'close'</span>, <b>function</b>(<a href="/source/s?defs=code">code</a>) {
<a class="l" name="91" href="#91">91</a>        <b>if</b> (<a href="/source/s?defs=code">code</a> !== <span class="n">0</span>) {
<a class="l" name="92" href="#92">92</a>            <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=log">log</a>(<span class="s">'Enlist process exited with code '</span> + <a href="/source/s?defs=code">code</a>);
<a class="l" name="93" href="#93">93</a>            <a href="/source/s?defs=callback">callback</a>(<span class="s">'Enlist process exited with code '</span> + <a href="/source/s?defs=code">code</a>);
<a class="l" name="94" href="#94">94</a>        } <b>else</b> {
<a class="l" name="95" href="#95">95</a>            <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">"Enlist done with code: "</span>+<a href="/source/s?defs=code">code</a>);
<a class="l" name="96" href="#96">96</a>            <a href="/source/s?defs=callback">callback</a>(<b>null</b>, <a href="/source/s?defs=enlister">enlister</a>);
<a class="l" name="97" href="#97">97</a>        }
<a class="l" name="98" href="#98">98</a>    });
<a class="l" name="99" href="#99">99</a>};
<a class="hl" name="100" href="#100">100</a>
<a class="l" name="101" href="#101">101</a><a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=create">create</a> = <b>function</b>(<a href="/source/s?defs=data">data</a>, <a href="/source/s?defs=callback">callback</a>) {
<a class="l" name="102" href="#102">102</a>    <b>var</b> <a href="/source/s?defs=enlister">enlister</a> = <b>new</b> <a class="d" href="#Enlister">Enlister</a>(<a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=name">name</a>, <a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=url">url</a>, <a href="/source/s?defs=data">data</a>.<a href="/source/s?defs=type">type</a>);
<a class="l" name="103" href="#103">103</a>    <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">'just created: %j'</span>, <a href="/source/s?defs=enlister">enlister</a>);
<a class="l" name="104" href="#104">104</a>    <a href="/source/s?defs=enlister">enlister</a>.<a href="/source/s?defs=prepare">prepare</a>(<b>function</b>(<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=result">result</a>){
<a class="l" name="105" href="#105">105</a>        <b>if</b> (<a href="/source/s?defs=err">err</a>) <a href="/source/s?defs=callback">callback</a>(<a href="/source/s?defs=err">err</a>);
<a class="l" name="106" href="#106">106</a>        <a href="/source/s?defs=callback">callback</a>(<b>null</b>, <a href="/source/s?defs=result">result</a>);
<a class="l" name="107" href="#107">107</a>    });
<a class="l" name="108" href="#108">108</a>};
<a class="l" name="109" href="#109">109</a>
<a class="hl" name="110" href="#110">110</a><a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=start_service">start_service</a> = <b>function</b>(<a href="/source/s?defs=config">config</a>, <a href="/source/s?defs=callback">callback</a>) {
<a class="l" name="111" href="#111">111</a>    <a href="/source/s?defs=sock_enlist">sock_enlist</a>.<a href="/source/s?defs=connect">connect</a>(<a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=enlist_url">enlist_url</a>);
<a class="l" name="112" href="#112">112</a>    <a href="/source/s?defs=sock_index">sock_index</a>.<a href="/source/s?defs=bindSync">bindSync</a>(<a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=index_url">index_url</a>);
<a class="l" name="113" href="#113">113</a>    <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">'Worker connected to enlist queue: '</span>+<a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=enlist_url">enlist_url</a>);
<a class="l" name="114" href="#114">114</a>    <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">'Worker bound to index queue: '</span>+<a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=index_url">index_url</a>);
<a class="l" name="115" href="#115">115</a>    <a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=RootFolder">RootFolder</a> = <a href="/source/s?defs=config">config</a>.<a href="/source/s?defs=root_folder">root_folder</a>||<a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=RootFolder">RootFolder</a>;
<a class="l" name="116" href="#116">116</a>    <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">'Enlister is using '</span>+<a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=RootFolder">RootFolder</a>+<span class="s">' as root.'</span>);
<a class="l" name="117" href="#117">117</a>    <a href="/source/s?defs=sock_enlist">sock_enlist</a>.<a href="/source/s?defs=on">on</a>(<span class="s">'message'</span>, <b>function</b>(<a href="/source/s?defs=name">name</a>, <a href="/source/s?defs=url">url</a>, <a href="/source/s?defs=type">type</a>){
<a class="l" name="118" href="#118">118</a>        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=time">time</a>(<span class="s">'enlist-'</span>+<a href="/source/s?defs=name">name</a>);
<a class="l" name="119" href="#119">119</a>        <a class="d" href="#Enlister">Enlister</a>.<a href="/source/s?defs=create">create</a>({
<a class="hl" name="120" href="#120">120</a>            <a href="/source/s?defs=name">name</a>:<a href="/source/s?defs=name">name</a>.<a href="/source/s?defs=toString">toString</a>(),
<a class="l" name="121" href="#121">121</a>            <a href="/source/s?defs=url">url</a>:<a href="/source/s?defs=url">url</a>.<a href="/source/s?defs=toString">toString</a>(),
<a class="l" name="122" href="#122">122</a>            <a href="/source/s?defs=type">type</a>:<a href="/source/s?defs=type">type</a>.<a href="/source/s?defs=toString">toString</a>()
<a class="l" name="123" href="#123">123</a>        }, <b>function</b>(<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=result">result</a>){
<a class="l" name="124" href="#124">124</a>            <b>if</b> (<a href="/source/s?defs=err">err</a>) <a href="/source/s?defs=callback">callback</a>(<span class="s">'enlist prepare err:\n'</span>+<a href="/source/s?defs=err">err</a>);
<a class="l" name="125" href="#125">125</a>            <b>else</b> {
<a class="l" name="126" href="#126">126</a>                <a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=enlist">enlist</a>(<b>function</b>(<a href="/source/s?defs=err">err</a>, <a href="/source/s?defs=result">result</a>){
<a class="l" name="127" href="#127">127</a>                    <b>if</b> (<a href="/source/s?defs=err">err</a>) <a href="/source/s?defs=callback">callback</a>(<span class="s">'enlist err:\n'</span>+<a href="/source/s?defs=err">err</a>);
<a class="l" name="128" href="#128">128</a>                    <b>else</b> {
<a class="l" name="129" href="#129">129</a>                        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=timeEnd">timeEnd</a>(<span class="s">'enlist-'</span>+<a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_name">_name</a>);
<a class="hl" name="130" href="#130">130</a>                        <a href="/source/s?defs=console">console</a>.<a href="/source/s?defs=info">info</a>(<span class="s">'enlist worker: %s[%s]: %s'</span>, <a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_name">_name</a>, <a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_type">_type</a>, <a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_url">_url</a>);
<a class="l" name="131" href="#131">131</a>                        <a href="/source/s?defs=sock_index">sock_index</a>.<a href="/source/s?defs=send">send</a>([<a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_name">_name</a>, <a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_path">_path</a>,
<a class="l" name="132" href="#132">132</a>                            <a href="/source/s?defs=path">path</a>.<a href="/source/s?defs=resolve">resolve</a>(<a href="/source/s?defs=path">path</a>.<a href="/source/s?defs=join">join</a>(<a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_path">_path</a>,<span class="s">".."</span>,<a href="/source/s?defs=result">result</a>.<a href="/source/s?defs=_name">_name</a>+<span class="s">"=grok"</span>))]);
<a class="l" name="133" href="#133">133</a>                    }
<a class="l" name="134" href="#134">134</a>                });
<a class="l" name="135" href="#135">135</a>            }
<a class="l" name="136" href="#136">136</a>        });
<a class="l" name="137" href="#137">137</a>    });
<a class="l" name="138" href="#138">138</a>};
<a class="l" name="139" href="#139">139</a>